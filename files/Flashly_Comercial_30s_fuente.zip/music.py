"""Pista de 30 s a 120 BPM para el comercial de Flashly, con efectos sincronizados a los cortes del video."""
import numpy as np
from scipy import signal
from scipy.io import wavfile

SR = 44100
DUR = 30.0
N = int(SR * DUR)
rng = np.random.default_rng(42)
L = np.zeros(N)
R = np.zeros(N)
BUS_REV = np.zeros((2, N))        # envío a reverb
DUCK_KEYS = []                     # tiempos de bombo para el sidechain
PAD = np.zeros((2, N)); BASS = np.zeros((2, N)); ARP = np.zeros((2, N))


def mf(m):
    return 440.0 * 2 ** ((m - 69) / 12)


def tt(d):
    return np.arange(int(SR * d)) / SR


def bp(x, lo, hi, order=2):
    sos = signal.butter(order, [lo, hi], btype='band', fs=SR, output='sos')
    return signal.sosfilt(sos, x)


def lp(x, fc, order=2):
    sos = signal.butter(order, fc, btype='low', fs=SR, output='sos')
    return signal.sosfilt(sos, x)


def hp(x, fc, order=2):
    sos = signal.butter(order, fc, btype='high', fs=SR, output='sos')
    return signal.sosfilt(sos, x)


def put(at, x, g=1.0, pan=0.0, rev=0.0, bus=None):
    """Suma una señal mono en el instante `at` (s) con paneo (-1..1) y envío de reverb."""
    i0 = int(round(at * SR))
    if i0 >= N:
        return
    if i0 < 0:
        x = x[-i0:]; i0 = 0
    x = x[: N - i0] * g
    gl = np.sqrt(0.5 * (1 - pan)); gr = np.sqrt(0.5 * (1 + pan))
    if bus is None:
        L[i0:i0 + len(x)] += x * gl; R[i0:i0 + len(x)] += x * gr
    else:
        bus[0, i0:i0 + len(x)] += x * gl; bus[1, i0:i0 + len(x)] += x * gr
    if rev:
        BUS_REV[0, i0:i0 + len(x)] += x * gl * rev; BUS_REV[1, i0:i0 + len(x)] += x * gr * rev


# ---------- instrumentos ----------
def kick(big=False):
    t = tt(0.9 if big else 0.45)
    f = 52 + 120 * np.exp(-t / 0.025)
    ph = 2 * np.pi * np.cumsum(f) / SR
    x = np.sin(ph) * np.exp(-t / (0.3 if big else 0.13))
    click = rng.normal(0, 1, len(t)) * np.exp(-t / 0.003) * 0.5
    return np.tanh(1.8 * (x + hp(click, 2000))) * 0.95


def sub_boom():
    t = tt(2.2)
    f = 40 + 40 * np.exp(-t / 0.15)
    return np.sin(2 * np.pi * np.cumsum(f) / SR) * np.exp(-t / 0.7)


def clap():
    t = tt(0.35); x = np.zeros(len(t))
    for k, off in enumerate([0, 0.011, 0.022]):
        i = int(off * SR)
        n = rng.normal(0, 1, len(t) - i) * np.exp(-tt((len(t) - i) / SR) / (0.012 if k < 2 else 0.13))
        x[i:] += n
    return bp(x, 900, 4200) * 1.4


def snare():
    t = tt(0.25)
    body = np.sin(2 * np.pi * 190 * t) * np.exp(-t / 0.05)
    nz = bp(rng.normal(0, 1, len(t)), 1500, 8000) * np.exp(-t / 0.08)
    return body * 0.6 + nz * 0.9


def hat(open_=False):
    t = tt(0.3 if open_ else 0.06)
    return hp(rng.normal(0, 1, len(t)), 7500, 4) * np.exp(-t / (0.12 if open_ else 0.018))


def crash(d=2.4):
    t = tt(d)
    x = hp(rng.normal(0, 1, len(t)), 3800, 2) * np.exp(-t / 0.75)
    return x * (1 - np.exp(-t / 0.002))


def riser(d, f0=300, f1=7000):
    t = tt(d)
    nz = rng.normal(0, 1, len(t))
    out = np.zeros(len(t)); seg = 2048
    for i in range(0, len(t), seg):
        k = i / len(t); fc = f0 * (f1 / f0) ** k
        out[i:i + seg] = bp(nz[i:i + seg], fc * 0.7, min(fc * 1.4, 16000), 1)
    tone = np.sin(2 * np.pi * np.cumsum(200 * (6 ** (t / d))) / SR) * 0.25
    env = (t / d) ** 2.2
    return (out * 1.6 + tone) * env


def whoosh(d=0.45, up=True):
    t = tt(d)
    nz = rng.normal(0, 1, len(t)); out = np.zeros(len(t)); seg = 1024
    for i in range(0, len(t), seg):
        k = i / len(t); k = k if up else 1 - k
        fc = 400 * (12 ** k)
        out[i:i + seg] = bp(nz[i:i + seg], fc * 0.6, min(fc * 1.6, 16000), 1)
    env = np.sin(np.pi * np.clip(t / d, 0, 1)) ** 1.5
    return out * env * 1.5


def bell(m, d=0.6, bright=0.3):
    t = tt(d); f = mf(m)
    x = np.sin(2 * np.pi * f * t) + bright * np.sin(2 * np.pi * f * 2.0 * t) * np.exp(-t / 0.1) + 0.12 * np.sin(2 * np.pi * f * 3.01 * t)
    return x * np.exp(-t / (d / 3.5)) * (1 - np.exp(-t / 0.002))


def tick():
    t = tt(0.05)
    return (np.sin(2 * np.pi * 2300 * t) * 0.7 + hp(rng.normal(0, 1, len(t)), 3000) * 0.3) * np.exp(-t / 0.008)


def thwack():
    t = tt(0.3)
    nz = lp(rng.normal(0, 1, len(t)), 2500) * np.exp(-t / 0.04)
    th = np.sin(2 * np.pi * np.cumsum(90 + 140 * np.exp(-t / 0.02)) / SR) * np.exp(-t / 0.09)
    return nz * 0.9 + th


def bloop(f0=500, f1=1100, d=0.14):
    t = tt(d)
    f = f0 + (f1 - f0) * (1 - np.exp(-t / 0.03))
    return np.sin(2 * np.pi * np.cumsum(f) / SR) * np.exp(-t / 0.05) * (1 - np.exp(-t / 0.002))


def saw(f, d, detune=0.0):
    t = tt(d)
    return signal.sawtooth(2 * np.pi * f * (1 + detune) * t + rng.uniform(0, 6.28))


# ---------- armonía ----------
# Am – F – C – G   (raíces y acordes en MIDI)
CH = {
    'Am': [57, 60, 64, 69], 'F': [53, 57, 60, 65], 'C': [55, 60, 64, 67], 'G': [55, 59, 62, 67],
}
ROOT = {'Am': 45, 'F': 41, 'C': 48, 'G': 43}
# (inicio, fin, acorde)
PROG = [(0, 3.0, 'Am'), (3, 5, 'Am'), (5, 7, 'F'), (7, 9, 'C'), (9, 11, 'G'), (11, 13, 'Am'), (13, 15, 'F'),
        (15, 17, 'C'), (17, 19, 'G'), (19, 20.5, 'Am'), (20.5, 22, 'F'), (22, 24, 'Am'), (24, 25.5, 'F'),
        (25.5, 27.5, 'C'), (27.5, 29.0, 'G'), (29.0, 30, 'C')]


def chord_at(t):
    for a, b, c in PROG:
        if a <= t < b:
            return c
    return 'C'


def pad_chord(a, b, c, g=0.16):
    d = b - a + 0.6
    t = tt(d)
    x = np.zeros(len(t))
    for m in CH[c]:
        for dt in (-0.006, 0.0, 0.007):
            x += saw(mf(m), d, dt)
    x = lp(x, 1800)
    env = np.minimum(1, t / 0.25) * np.clip((d - t) / 0.6, 0, 1)
    put(a, x * env, g / 5, 0.0, rev=0.5, bus=PAD)


for a, b, c in PROG:
    pad_chord(a, b, c)

# ---------- secciones ----------
def groove(a, b, arp=True, bass=True, hats=True):
    t = a
    while t < b - 1e-6:
        beat = int(round((t - 3.0) / 0.5)) % 4
        put(t, kick(), 0.7); DUCK_KEYS.append(t)
        if beat in (1, 3):
            put(t, clap(), 0.55, 0.0, rev=0.25)
        if hats:
            put(t + 0.25, hat(True), 0.13, 0.25)
            for s in (0.125, 0.375):
                put(t + s, hat(), 0.08, -0.3)
        if bass:
            c = chord_at(t + 0.25)
            f = mf(ROOT[c])
            note = saw(f, 0.22) * 0.6 + saw(f, 0.22, 0.004) * 0.6 + np.sin(2 * np.pi * f / 2 * tt(0.22)) * 0.8
            env = np.minimum(1, tt(0.22) / 0.005) * np.exp(-tt(0.22) / 0.16)
            put(t + 0.25, lp(note, 1100) * env, 0.42, 0.0, bus=BASS)
        t += 0.5
    if arp:
        t = a; k = 0
        while t < b - 1e-6:
            c = chord_at(t)
            notes = CH[c] + [CH[c][1] + 12]
            pattern = [0, 2, 1, 3, 4, 2, 3, 1]
            m = notes[pattern[k % 8]] + 12
            d = 0.2
            x = (signal.square(2 * np.pi * mf(m) * tt(d), 0.3) * 0.5 + saw(mf(m), d) * 0.5)
            x = lp(x, 3200) * np.exp(-tt(d) / 0.07) * np.minimum(1, tt(d) / 0.003)
            pan = 0.35 if k % 2 else -0.35
            put(t, x, 0.16, pan, rev=0.3, bus=ARP)
            put(t + 0.1875, x, 0.065, -pan, bus=ARP)  # eco 3/16
            put(t + 0.375, x, 0.03, pan, bus=ARP)
            t += 0.125; k += 1


# Intro 0–3: hats suaves + golpes en cada palabra del gancho + subida
for i in range(int(2.75 / 0.25)):
    put(0.25 * i + 0.125, hat(), 0.05, 0.3 if i % 2 else -0.3)
for at in (0.06, 0.48, 1.52, 1.94):
    put(at, kick(), 0.55); put(at, thwack(), 0.18, 0, rev=0.3)
put(1.45, riser(1.4), 0.32, 0, rev=0.2)

# Drop 3.0
put(3.0, kick(True), 0.9); put(3.0, sub_boom(), 0.35); put(3.0, crash(), 0.3, 0.1, rev=0.4)
groove(3.0, 19.0)

# Breakdown 19–22: sin bombo, palmas a medio tiempo, sub sostenido
put(19.0, sub_boom(), 0.22); put(19.0, crash(2.0), 0.18, -0.1, rev=0.5)
for at in (20.0, 21.0):
    put(at, clap(), 0.4, 0, rev=0.45)
for a, b, c in [(19.0, 20.5, 'Am'), (20.5, 22.0, 'F')]:
    f = mf(ROOT[c]) / 2; d = b - a
    put(a, np.sin(2 * np.pi * f * tt(d)) * np.minimum(1, tt(d) / 0.05) * np.clip((d - tt(d)) / 0.1, 0, 1), 0.18, bus=BASS)
# redoble acelerando 21–22
t, step = 21.0, 0.125
while t < 21.98:
    put(t, snare(), 0.12 + 0.3 * (t - 21.0), (rng.random() - 0.5) * 0.3, rev=0.2)
    t += step; step = max(0.0625, step * 0.9)
put(20.9, riser(1.08, 400, 9000), 0.3, 0, rev=0.2)

# Re-drop 22
put(22.0, kick(True), 0.95); put(22.0, crash(), 0.26, -0.1, rev=0.4)
groove(22.0, 25.5)
put(24.9, riser(0.6, 500, 9000), 0.25)

# Final 25.5
put(25.5, kick(True), 0.9); put(25.5, sub_boom(), 0.38); put(25.5, crash(3.0), 0.32, 0.1, rev=0.5)
groove(25.5, 29.0, hats=True)
put(29.0, kick(True), 0.85); put(29.0, sub_boom(), 0.28); put(29.0, crash(2.0), 0.22, 0, rev=0.6)
for m in (60, 64, 67, 72):
    put(29.0, bell(m + 12, 1.6, 0.4), 0.06, (m - 66) / 10, rev=0.6)

# ---------- efectos sincronizados ----------
put(3.0, bell(81, 1.2, 0.5), 0.07, 0, rev=0.5)              # brillo del logo
put(4.12, whoosh(0.46), 0.16, -0.2)                          # morph a cabecera
put(5.25, bell(88, 0.5), 0.16, 0.1, rev=0.25); put(5.34, bell(93, 0.6), 0.14, 0.1, rev=0.3)   # notificación
buzz_t = tt(0.42)
put(5.25, (signal.square(2 * np.pi * 160 * buzz_t) * (0.5 + 0.5 * signal.square(2 * np.pi * 24 * buzz_t))) * np.exp(-buzz_t / 0.3), 0.05)
put(6.2, whoosh(0.6, False), 0.16, 0.2)                       # zoom out
pent = [76, 79, 81, 84, 86, 88, 91, 93]
for k, d in enumerate(sorted([1.0, 1.41, 1.0, 1.41, 1.41, 1.0, 1.0, 1.41])):
    at = 6.62 + (d + 0.35 * ((k * 37) % 7) / 7) * 0.16
    put(at, bell(pent[k], 0.35, 0.2), 0.045, -0.6 + k * 0.17, rev=0.3)
put(7.76, whoosh(0.32), 0.18)                                 # empuje a temporizador
for i in range(10):                                           # tic-tac del temporizador
    put(8.5 + 0.25 * i, tick(), 0.16 + 0.02 * i, 0.15 if i % 2 else -0.15)
put(10.5, riser(0.55, 600, 10000), 0.2); put(10.7, whoosh(0.42), 0.18)   # revelado circular
put(11.78, tick(), 0.25); put(11.86, thwack(), 0.12)          # obturador
t = tt(0.25)
put(11.98, hp(rng.normal(0, 1, len(t)), 5000) * np.exp(-t / 0.05) + np.sin(2 * np.pi * np.cumsum(3000 - 2000 * t / 0.25) / SR) * np.exp(-t / 0.06) * 0.3, 0.22, 0, rev=0.3)
put(12.05, bloop(400, 900), 0.18)                            # aparece la selfie
put(13.0, thwack(), 0.42, -0.25, rev=0.15); put(13.35, thwack(), 0.4, 0.25, rev=0.15)  # stickers
put(14.72, whoosh(0.32), 0.16)
put(16.3, tick(), 0.2)                                        # toque
for k, m in enumerate((81, 84, 88, 93)):                      # desbloqueo
    put(16.6 + 0.06 * k, bell(m, 0.7, 0.35), 0.08, -0.3 + 0.2 * k, rev=0.45)
put(16.6, whoosh(0.5), 0.12)
put(18.74, whoosh(0.3), 0.14)
for k, at in enumerate((19.9, 20.28, 20.56, 20.78, 20.95)):   # polaroids que se borran
    put(at, bp(rng.normal(0, 1, int(0.5 * SR)), 5000, 12000) * np.exp(-tt(0.5) / 0.12), 0.08, -0.5 + 0.25 * k, rev=0.5)
    put(at, bell(96 - k, 0.5, 0.1), 0.03, 0, rev=0.6)
put(21.72, whoosh(0.3), 0.14)
for k, at in enumerate((22.35, 22.52, 22.66, 22.78)):          # pines
    put(at, bloop(450 + 60 * k, 1000 + 120 * k), 0.2, [-0.4, 0.4, -0.3, 0.35][k], rev=0.2)
for k, at in enumerate((23.9, 24.0, 24.07)):                  # chips
    put(at, tick(), 0.08, -0.3 + 0.3 * k)
put(25.22, whoosh(0.3), 0.14)
put(26.2, bloop(300, 700, 0.2), 0.2)                          # CTA
t = tt(0.9)
put(27.25, bp(rng.normal(0, 1, len(t)), 6000, 14000) * np.sin(np.pi * t / 0.9) ** 2, 0.06, 0, rev=0.4)   # brillo del CTA

# ---------- sidechain y reverb ----------
duck = np.ones(N)
tN = np.arange(N) / SR
for k in DUCK_KEYS:
    i0 = int(k * SR); i1 = min(N, i0 + int(0.45 * SR))
    seg = tN[i0:i1] - k
    duck[i0:i1] = np.minimum(duck[i0:i1], 1 - 0.55 * np.exp(-seg / 0.11))
# breakdown: abre y cierra el filtro del pad
pad_lp = np.stack([lp(PAD[0], 500), lp(PAD[1], 500)])
mix_k = np.ones(N)
m = (tN >= 19.0) & (tN < 22.0)
mix_k[m] = np.clip(1 - np.sin(np.pi * (tN[m] - 19.0) / 3.0) * 0.9, 0, 1)
pad_mix = PAD * mix_k + pad_lp * (1 - mix_k)
intro = tN < 3.0
pad_mix[:, intro] = pad_lp[:, intro] * 1.6
for bus, g in ((pad_mix, 1.0), (BASS, 1.0), (ARP, 1.0)):
    L += bus[0] * duck * g; R += bus[1] * duck * g

ir_t = tt(2.2)
ir = [rng.normal(0, 1, len(ir_t)) * np.exp(-ir_t / 0.55) for _ in range(2)]
ir = [lp(x, 6000) / np.sqrt(np.sum(x ** 2)) for x in ir]
rev = [signal.fftconvolve(BUS_REV[i], ir[i])[:N] for i in range(2)]
L += rev[0] * 0.9; R += rev[1] * 0.9

# silencio de tensión justo antes del drop
gap = (tN > 2.86) & (tN < 3.0)
L[gap] *= 0.15; R[gap] *= 0.15

# ---------- master ----------
mix = np.stack([L, R])
mix = signal.sosfilt(signal.butter(2, 28, 'high', fs=SR, output='sos'), mix)
mix = mix / np.max(np.abs(mix)) * 1.4
mix = np.tanh(mix) / np.tanh(1.4)
fade = np.clip((DUR - tN) / 0.5, 0, 1)
mix *= fade
mix = mix / np.max(np.abs(mix)) * 0.89
wavfile.write('out/music.wav', SR, (mix.T * 32767).astype(np.int16))
print('ok', mix.shape, float(np.sqrt(np.mean(mix ** 2))))
