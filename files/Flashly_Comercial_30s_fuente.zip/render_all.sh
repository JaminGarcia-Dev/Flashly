#!/bin/bash
export NODE_PATH=$(npm root -g)
cd /home/claude/work/video
segs=("0 3" "3 4.5" "4.5 8" "8 10.7" "10.7 15" "15 19" "19 22" "22 25.5" "25.5 30")
i=0
for s in "${segs[@]}"; do
  set -- $s
  node render.js video $1 $2 out/seg$(printf %02d $i).mp4
  i=$((i+1))
done
echo DONE
