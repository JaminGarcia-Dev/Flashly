import * as THREE from 'three';
import { makePhone, DIM } from './phone.js';
import * as S from './screens.js';

/* ---------- utilidades de tiempo ---------- */
const clamp = (v, a = 0, b = 1) => Math.min(b, Math.max(a, v));
const lerp = (a, b, k) => a + (b - a) * k;
function bez(x1, y1, x2, y2) {
  return x => { if (x <= 0) return 0; if (x >= 1) return 1; let lo = 0, hi = 1, t = .5;
    for (let i = 0; i < 24; i++) { t = (lo + hi) / 2; const cx = 3 * x1 * t * (1 - t) ** 2 + 3 * x2 * t * t * (1 - t) + t ** 3; if (cx < x) lo = t; else hi = t; }
    return 3 * y1 * t * (1 - t) ** 2 + 3 * y2 * t * t * (1 - t) + t ** 3; };
}
const OUT = bez(.23, 1, .32, 1), INOUT = bez(.77, 0, .175, 1), SMOOTH = bez(.45, 0, .55, 1), DRAWER = bez(.32, .72, 0, 1);
const P = (t, a, d, e = OUT) => e(clamp((t - a) / d));
function SPR(k, z = .62, w = 10) { if (k <= 0) return 0; if (k >= 1) return 1; const wd = w * Math.sqrt(1 - z * z);
  return 1 - Math.exp(-z * w * k) * (Math.cos(wd * k) + (z * w / wd) * Math.sin(wd * k)); }
const v3 = (x, y, z) => new THREE.Vector3(x, y, z);
const lv = (a, b, k) => a.clone().lerp(b, k);

/* ---------- render ---------- */
const W = 1080, H = 1920;
const canvas = document.getElementById('gl');
const Q = new URLSearchParams(location.search);
const renderer = new THREE.WebGLRenderer({ canvas, antialias: Q.get('aa') !== '0', preserveDrawingBuffer: true, powerPreference: 'high-performance' });
renderer.setPixelRatio(1); renderer.setSize(W, H, false);
renderer.toneMapping = THREE.ACESFilmicToneMapping; renderer.toneMappingExposure = 1.05;
renderer.outputColorSpace = THREE.SRGBColorSpace;
const scene = new THREE.Scene(); scene.background = new THREE.Color(0x000000);
const camera = new THREE.PerspectiveCamera(30, W / H, 0.5, 3000);

/* entorno de estudio: tiras de luz sobre negro (dan los brillos de los bordes) */
function buildEnv() {
  const es = new THREE.Scene(); es.background = new THREE.Color(0x000000);
  const strip = (w, h, pos, int, col = 0xffffff) => {
    const m = new THREE.Mesh(new THREE.PlaneGeometry(w, h), new THREE.MeshBasicMaterial({ color: new THREE.Color(col).multiplyScalar(int), side: THREE.DoubleSide }));
    m.position.copy(pos); m.lookAt(0, 0, 0); es.add(m);
  };
  strip(2.4, 34, v3(-15, 3, 7), 7.0);
  strip(1.6, 34, v3(15, 0, -5), 5.0);
  strip(26, 2.2, v3(0, 17, 3), 2.6);
  strip(8, 5, v3(5, -8, 15), 0.9, 0xffe2c0);
  strip(5, 20, v3(-6, 2, -16), 1.6, 0xb7a6ff);
  const pm = new THREE.PMREMGenerator(renderer);
  return pm.fromScene(es, 0.02, 0.1, 100).texture;
}
scene.environment = buildEnv();
const keyLight = new THREE.DirectionalLight(0xffffff, 0); keyLight.position.set(-6, 9, 10); scene.add(keyLight);
const rimLight = new THREE.DirectionalLight(0xb9a6ff, 0); rimLight.position.set(9, 4, -7); scene.add(rimLight);

/* texturas */
function canvasTex(w = S.SW, h = S.SH) {
  const c = document.createElement('canvas'); c.width = w; c.height = h;
  const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; t.anisotropy = 8;
  t.minFilter = THREE.LinearMipmapLinearFilter; t.generateMipmaps = true;
  return { c, ctx: c.getContext('2d'), t };
}
function radialTex(stops) {
  const c = document.createElement('canvas'); c.width = c.height = 512; const g = c.getContext('2d');
  const rg = g.createRadialGradient(256, 256, 0, 256, 256, 256);
  stops.forEach(([o, col]) => rg.addColorStop(o, col)); g.fillStyle = rg; g.fillRect(0, 0, 512, 512);
  const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; return t;
}
function textPlane(str, { px = 340, weight = 700, worldW = 20, tracking = -0.045 } = {}) {
  const c = document.createElement('canvas'); const g = c.getContext('2d');
  g.font = `${weight} ${px}px ID`; g.letterSpacing = (px * tracking) + 'px';
  const tw = g.measureText(str).width;
  c.width = Math.ceil(tw + px * 0.4); c.height = Math.ceil(px * 1.35);
  g.font = `${weight} ${px}px ID`; g.letterSpacing = (px * tracking) + 'px'; g.textAlign = 'center'; g.textBaseline = 'middle';
  const gr = g.createLinearGradient(0, 0, 0, c.height);   // blanco a titanio, como los titulares de keynote
  gr.addColorStop(0.15, '#FFFFFF'); gr.addColorStop(1, '#9A98A2');
  g.fillStyle = gr; g.fillText(str, c.width / 2, c.height * 0.54);
  const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; t.anisotropy = 8;
  const m = new THREE.Mesh(new THREE.PlaneGeometry(worldW, worldW * c.height / c.width),
    new THREE.MeshBasicMaterial({ map: t, transparent: true, toneMapped: false, depthWrite: false, opacity: 0, fog: false }));
  m.renderOrder = -1; return m;
}

let hero, heroScr, left, right, texDisc, texChat, grid, gridScr, gridTex, glowAmber, glowViolet, glowFlash, words = {};
const GRID = { cols: 13, rows: 17, dx: 10.2, dy: 19.0 };
let gridCells = [];

async function build() {
  await S.loadAssets();
  heroScr = canvasTex();
  hero = makePhone(heroScr.t); scene.add(hero);

  texDisc = canvasTex(); S.drawDiscover(texDisc.ctx); texDisc.t.needsUpdate = true;
  texChat = canvasTex(); S.drawChat(texChat.ctx); texChat.t.needsUpdate = true;
  left = makePhone(texDisc.t); right = makePhone(texChat.t);
  scene.add(left, right); left.visible = right.visible = false;

  // rejilla de teléfonos (instanciada): marco + pantalla
  gridTex = canvasTex(); S.drawLock(gridTex.ctx, { minute: 47, notif: 1 }); gridTex.t.needsUpdate = true;
  const { w, h, d, r } = DIM;
  const sh = new THREE.Shape(); { const x = -w / 2, y = -h / 2;
    sh.moveTo(x + r, y); sh.lineTo(x + w - r, y); sh.quadraticCurveTo(x + w, y, x + w, y + r); sh.lineTo(x + w, y + h - r);
    sh.quadraticCurveTo(x + w, y + h, x + w - r, y + h); sh.lineTo(x + r, y + h); sh.quadraticCurveTo(x, y + h, x, y + h - r);
    sh.lineTo(x, y + r); sh.quadraticCurveTo(x, y, x + r, y); }
  const fGeo = new THREE.ExtrudeGeometry(sh, { depth: d, bevelEnabled: false, curveSegments: 10 }); fGeo.translate(0, 0, -d / 2);
  const sw = w - 0.52, shh = h - 0.52;
  const sGeo = new THREE.PlaneGeometry(sw, shh);
  const n = GRID.cols * GRID.rows;
  grid = new THREE.InstancedMesh(fGeo, new THREE.MeshStandardMaterial({ color: 0x2a2830, metalness: 1, roughness: 0.32 }), n);
  gridScr = new THREE.InstancedMesh(sGeo, new THREE.MeshBasicMaterial({ map: gridTex.t, toneMapped: false }), n);
  const M = new THREE.Matrix4();
  let i = 0;
  for (let ry = 0; ry < GRID.rows; ry++) for (let cx = 0; cx < GRID.cols; cx++) {
    const gx = cx - (GRID.cols - 1) / 2, gy = ry - (GRID.rows - 1) / 2;
    const center = gx === 0 && gy === 0;
    const jit = (Math.sin(i * 12.9898) * 43758.5453) % 1;
    const pos = v3(gx * GRID.dx, gy * GRID.dy, -Math.abs(jit) * 3);
    M.compose(pos, new THREE.Quaternion(), center ? v3(0.0001, 0.0001, 0.0001) : v3(1, 1, 1));
    grid.setMatrixAt(i, M);
    M.compose(pos.clone().add(v3(0, 0, d / 2 + 0.01)), new THREE.Quaternion(), center ? v3(0.0001, 0.0001, 0.0001) : v3(1, 1, 1));
    gridScr.setMatrixAt(i, M);
    gridScr.setColorAt(i, new THREE.Color(0.02, 0.02, 0.02));
    gridCells.push({ i, dist: Math.hypot(gx, gy * 1.6) + Math.abs(jit) * 0.6 });
    i++;
  }
  gridScr.instanceColor.needsUpdate = true;
  scene.add(grid, gridScr); grid.visible = gridScr.visible = false;

  // halos aditivos
  const mk = (tex, s) => { const sp = new THREE.Sprite(new THREE.SpriteMaterial({ map: tex, blending: THREE.AdditiveBlending, depthWrite: false, transparent: true, toneMapped: false, fog: false })); sp.scale.set(s, s, 1); scene.add(sp); return sp; };
  glowAmber = mk(radialTex([[0, 'rgba(255,190,70,0.9)'], [0.35, 'rgba(255,140,40,0.35)'], [1, 'rgba(0,0,0,0)']]), 60);
  glowViolet = mk(radialTex([[0, 'rgba(150,100,255,0.55)'], [0.4, 'rgba(194,79,224,0.18)'], [1, 'rgba(0,0,0,0)']]), 80);
  glowFlash = mk(radialTex([[0, 'rgba(255,255,255,1)'], [0.12, 'rgba(255,245,220,0.8)'], [0.4, 'rgba(255,220,160,0.15)'], [1, 'rgba(0,0,0,0)']]), 20);
  glowAmber.renderOrder = glowViolet.renderOrder = -2;

  // palabras gigantes detrás del teléfono
  words.ahora = textPlane('Ahora.', { worldW: 21 });
  words.min = textPlane('2 minutos.', { worldW: 22 });
  words.h24 = textPlane('24 h', { worldW: 19 });
  Object.values(words).forEach(m => { m.position.set(0, 0, -16); scene.add(m); });
}

/* ---------- copy DOM ---------- */
const $ = id => document.getElementById(id);
function copy(id, t, times, outAt, { rise = 26, dur = .8 } = {}) {
  const el = $(id); const spans = el.querySelectorAll('span');
  const on = t >= times[0] - .05 && t < outAt + .6;
  el.style.display = on ? 'block' : 'none'; if (!on) return;
  spans.forEach((s, i) => {
    const k = P(t, times[Math.min(i, times.length - 1)], dur);
    const ko = P(t, outAt, .45, SMOOTH);
    s.style.opacity = k * (1 - ko);
    s.style.filter = `blur(${(1 - k) * 10 + ko * 8}px)`;
    s.style.display = 'inline-block';
    s.style.transform = `translateY(${(1 - k) * rise}px)`;
  });
}

/* ---------- pantallas del héroe por cuadro ---------- */
function heroScreen(t) {
  const ctx = heroScr.ctx;
  if (t < 9.5 + 4.5) {
    // bloqueo: despierta, cambia el minuto, cae la notificación
    const wake = t < 5.0 ? 0 : P(t, 5.2, .35);
    const minute = t < 5.75 ? 46 : 47;
    const notif = t < 6.0 ? 0 : SPR(clamp((t - 6.0) / .7), .68, 10);
    const glow = t < 6.0 ? 0 : Math.exp(-(t - 6.0) / .25) * .9;
    S.drawLock(ctx, { minute, notif, wake, glow });
  } else if (t < 19.0 + 2.0) {
    const ticks = clamp(Math.floor((t - 14.5) / .5) + 1, 0, 14);
    const pulse = t > 14.5 ? 1 - P(t, 14.5 + (ticks - 1) * .5, .3) : 0;
    S.drawHome(ctx, { secs: 120 - ticks, ring: P(t, 14.0, .8), pulse });
  } else if (t < 25.0) {
    const press = t > 22.6 && t < 22.9 ? Math.sin(clamp((t - 22.6) / .3) * Math.PI) : 0;
    S.drawCamera(ctx, {
      zoom: 1.02 + Math.min(t, 23.0) * 0.004 - press * 0.01,
      inset: t < 23.05 ? 0 : SPR(clamp((t - 23.05) / .6), .6, 11),
      flash: t < 22.98 ? 0 : Math.exp(-(t - 22.98) / .14),
      secs: 104 - Math.floor(Math.max(0, t - 21.5)),
      captured: P(t, 23.6, .4),
    });
  } else if (t < 32.0) {
    S.drawFeed(ctx, {
      blur: 34 * (1 - P(t, 27.75, .65)), lock: 1 - P(t, 27.75, .3), tap: t >= 27.4 ? (t - 27.4) / .4 : -1,
      scroll: P(t, 28.6, 2.0, INOUT) * 1500,
    });
  } else if (t < 35.5) {
    const k = P(t, 32.0, 1.0, SMOOTH);
    if (k < 1) { S.drawFeed(ctx, { scroll: 1500, blur: k * 24, dim: k }); }
    if (k > 0) { ctx.save(); ctx.globalAlpha = k; S.drawWaiting(ctx); ctx.restore(); }
  } else {
    S.drawFeed(ctx, { scroll: 0 });
  }
  heroScr.t.needsUpdate = true;
}

/* ---------- planos ---------- */
function setCam(pos, target, fov = 30, roll = 0) {
  camera.position.copy(pos); camera.up.set(Math.sin(roll), Math.cos(roll), 0); camera.lookAt(target);
  if (camera.fov !== fov) { camera.fov = fov; camera.updateProjectionMatrix(); }
}
function resetFrame() {
  hero.visible = true; hero.position.set(0, 0, 0); hero.rotation.set(0, 0, 0); hero.scale.setScalar(1);
  left.visible = right.visible = false; grid.visible = gridScr.visible = false;
  scene.fog = null; scene.environmentIntensity = 1; scene.environmentRotation.set(0, 0, 0);
  glowAmber.material.opacity = 0; glowViolet.material.opacity = 0; glowFlash.material.opacity = 0;
  Object.values(words).forEach(m => { m.material.opacity = 0; m.visible = false; });
  hero.userData.flashMat.color.setRGB(1, 0.95, 0.82);
  hero.userData.sweep.material.opacity = 0; hero.userData.sweepBack.material.opacity = 0;
  keyLight.intensity = 0.6; rimLight.intensity = 1.2; keyLight.position.set(-6, 9, 10); rimLight.position.set(9, 4, -7);
}

function render(t) {
  resetFrame();
  heroScreen(t);
  let black = 0, flash = 0;

  if (t < 5.0) {                                   // S1 · el borde se revela
    const k = clamp(t / 5);
    hero.rotation.set(0.1, lerp(1.62, 0.5, SMOOTH(k)), lerp(0.05, -0.02, k));
    setCam(v3(lerp(0.8, -0.4, k), lerp(-4.5, -3.2, k), lerp(52, 44, SMOOTH(k))), v3(0, lerp(3.4, 3.0, k), 0), 30);
    scene.environmentIntensity = P(t, 0.1, 2.0, SMOOTH) * 1.5;
    scene.environmentRotation.set(0, lerp(-2.2, 0.5, SMOOTH(k)), 0);
    keyLight.intensity = 5 * P(t, 0.4, 2.0, SMOOTH); keyLight.position.set(lerp(-12, 8, k), 6, 8);
    rimLight.intensity = 7 * P(t, 0.1, 1.5, SMOOTH); rimLight.position.set(-10, 3, -6);
    const sw = hero.userData.sweep; sw.material.opacity = 0.85 * P(t, 0.6, .8, SMOOTH);
    sw.material.map.offset.x = lerp(-0.95, 0.95, SMOOTH(clamp((t - 0.6) / 4.0)));
    glowViolet.position.set(0, 0, -9); glowViolet.material.opacity = 0.16 * P(t, 1.0, 2.5, SMOOTH); glowViolet.scale.setScalar(70);
    black = P(t, 4.55, .45, SMOOTH);
  } else if (t < 9.5) {                            // S2 · Ahora.
    const k = clamp((t - 5) / 4.5);
    const vib = t > 6.0 && t < 6.6 ? Math.sin((t - 6.0) * 70) * 0.012 * Math.exp(-(t - 6.0) * 7) : 0;
    hero.rotation.set(0.05, lerp(-0.26, -0.08, SMOOTH(k)), vib);
    const pull = P(t, 9.0, 1.2, INOUT) * 0;  // el alejamiento sigue en S3
    setCam(v3(0, lerp(-3.2, -1.6, k), lerp(54, 44, SMOOTH(k))), v3(0, lerp(0.6, 0.2, k), 0), 30);
    scene.environmentRotation.set(0, lerp(0.25, -0.15, k), 0);
    const g = t < 6.0 ? 0 : 0.14 + 0.5 * Math.exp(-(t - 6.0) / .45);
    glowAmber.position.set(0, 0.5, -3); glowAmber.material.opacity = g * P(t, 6.0, .12); glowAmber.scale.setScalar(lerp(30, 46, P(t, 6.0, 1.2)));
    words.ahora.visible = true; words.ahora.position.set(0, 6.8, -16);
    const kw = P(t, 6.0, .9); words.ahora.material.opacity = kw * (1 - P(t, 9.1, .4, SMOOTH)); words.ahora.scale.setScalar(.94 + .06 * kw);
    black = 1 - P(t, 5.0, .25);
  } else if (t < 14.0) {                           // S3 · todo el campus, al mismo tiempo
    grid.visible = gridScr.visible = true;
    scene.fog = new THREE.Fog(0x000000, 110, 330);
    const k = P(t, 9.5, 3.6, INOUT);
    const back = P(t, 13.25, .75, bez(.7, 0, .84, 0));   // regreso rápido al héroe
    const far = v3(30, -150, 150), near = v3(0, -1.6, 44);
    const pos = lv(lv(near, far, k), v3(0, 1, 30), back);
    const tgt = lv(lv(v3(0, 0.2, 0), v3(0, 46, 0), k), v3(0, 0.2, 0), back);
    setCam(pos, tgt, 30, lerp(0, -0.06, k) * (1 - back));
    hero.rotation.set(0.05, lerp(-0.08, 0, k), 0);
    gridCells.forEach(c => {
      const at = 9.9 + c.dist * 0.17;
      let col;
      if (t < at) col = [0.03, 0.03, 0.035];
      else { const e = Math.exp(-(t - at) / .35); col = [1 + e * 1.4, 1 + e * 0.9, 1 + e * 0.1]; }
      gridScr.setColorAt(c.i, new THREE.Color(...col));
    });
    gridScr.instanceColor.needsUpdate = true;
    glowAmber.position.set(0, 0, -6); glowAmber.material.opacity = 0.16 * (1 - k * 0.5); glowAmber.scale.setScalar(40 + k * 200);
    flash = Math.max(0, (back - 0.85) / 0.15) * 0.0;
  } else if (t < 19.0) {                           // S4 · dos minutos
    const k = clamp((t - 14) / 5);
    hero.rotation.set(0.06, lerp(0.36, 0.14, SMOOTH(k)), 0);
    const arrive = P(t, 14.0, .9);
    setCam(v3(lerp(-0.8, 0.8, k), lerp(-2.0, -1.0, k), lerp(34, 51, arrive) - k * 2), v3(0, 1.0, 0), 30);
    scene.environmentRotation.set(0, lerp(-0.4, 0.3, k), 0);
    words.min.visible = true; words.min.position.set(0, 11.8, -16);
    const kw = P(t, 14.4, 1.0); words.min.material.opacity = kw * (1 - P(t, 18.6, .4, SMOOTH)); words.min.scale.setScalar(.95 + .05 * kw);
    glowAmber.position.set(0, 0, -5); glowAmber.material.opacity = 0.12; glowAmber.scale.setScalar(50);
  } else if (t < 25.0) {                           // S5 · dos cámaras
    const flip1 = P(t, 19.0, 1.1, INOUT), flip2 = P(t, 21.5, 1.15, INOUT);
    hero.rotation.set(0.05 * (1 - flip1) + 0.05 * flip2, lerp(0.16, Math.PI, flip1) + Math.PI * flip2 - (flip2 > 0 ? 0 : 0), 0);
    if (flip2 > 0) hero.rotation.y = lerp(Math.PI, Math.PI * 2 - 0.12, flip2);
    // la cámara se acerca a las lentes y luego regresa
    const lensW = v3(-(DIM.w / 2 - 1.55), DIM.h / 2 - 2.55, 0.6);
    const push = P(t, 19.6, 1.4, INOUT) * (1 - flip2);
    const base = v3(0.5, 0.5, 47);
    const close = v3(lensW.x + 2.2, lensW.y + 0.8, 21);
    const tgt = lv(v3(0, 1, 0), lensW, push);
    setCam(lv(base, close, push), tgt, 30);
    scene.environmentRotation.set(0, lerp(0.3, -0.6, flip1) + flip2 * 0.8, 0);
    // flash LED en 21.0
    const fl = t < 20.98 ? 0 : Math.exp(-(t - 20.98) / .22);
    hero.userData.flashMat.color.setRGB(1 + fl * 8, 0.95 + fl * 7.5, 0.82 + fl * 6);
    const lp = new THREE.Vector3(); hero.userData.camG.children[hero.userData.camG.children.length - 1].getWorldPosition(lp);
    hero.updateMatrixWorld(true); hero.userData.camG.children[hero.userData.camG.children.length - 1].getWorldPosition(lp);
    glowFlash.position.copy(lp).add(v3(0, 0, 0.5)); glowFlash.material.opacity = fl; glowFlash.scale.setScalar(4 + fl * 26);
    flash = fl * 0.22;
    glowFlash.scale.setScalar(1.2 + fl * 6);
    keyLight.intensity = 3.5; keyLight.position.set(-7, 9, 14); rimLight.intensity = 4; rimLight.position.set(10, 3, -6);
    const sb = hero.userData.sweepBack; sb.material.opacity = 0.35 * (1 - flip2); sb.material.map.offset.x = lerp(0.8, -0.6, SMOOTH(clamp((t - 19.2) / 2.2)));
    glowViolet.position.set(0, 0, -8); glowViolet.material.opacity = 0.35; glowViolet.scale.setScalar(90);
  } else if (t < 31.0) {                           // S6 · comparte para ver
    const k = clamp((t - 25) / 6);
    hero.rotation.set(0.04, lerp(-0.22, 0.1, SMOOTH(k)), 0);
    setCam(v3(lerp(1.5, -1, k), lerp(-1, 0.4, k), lerp(52, 45, SMOOTH(k))), v3(0, lerp(2.2, 2.6, k), 0), 30);
    scene.environmentRotation.set(0, lerp(-0.3, 0.4, k), 0);
    const unlock = P(t, 27.75, 1.2);
    glowViolet.position.set(0, 0, -7); glowViolet.material.opacity = 0.14 + unlock * 0.22; glowViolet.scale.setScalar(70 + unlock * 30);
    flash = t > 27.75 ? Math.exp(-(t - 27.75) / .2) * 0.12 : 0;
  } else if (t < 35.5) {                           // S7 · mañana ya no
    const k = clamp((t - 31) / 4.5);
    hero.rotation.set(0.03, lerp(0.05, 1.32, INOUT(k)), 0);
    setCam(v3(0, lerp(-1.0, -1.6, k), lerp(52, 45, SMOOTH(k))), v3(0, 1.2, 0), 30);
    scene.environmentRotation.set(0, lerp(0.2, 1.3, SMOOTH(k)), 0);
    words.h24.visible = true; words.h24.position.set(0, 12.2, -16);
    const kw = P(t, 31.3, 1.2); words.h24.material.opacity = kw * (1 - P(t, 35.0, .45, SMOOTH)); words.h24.scale.setScalar(.95 + .05 * kw);
    black = P(t, 35.05, .45, SMOOTH);
  } else if (t < 40.5) {                           // S8 · alineación de tres
    left.visible = right.visible = true;
    const e = (a) => P(t, a, 1.0, DRAWER);
    const kc = e(35.5), kl = e(35.68), kr = e(35.8);
    const out = P(t, 39.7, .8, INOUT);
    hero.position.set(0, lerp(-28, -1.6, kc), 1.5); hero.rotation.set(0.03, lerp(0, Math.PI / 2, out), 0);
    left.position.set(lerp(-5.4, -12, out), lerp(-30, -0.6, kl), -5); left.rotation.set(0.03, 0.42, 0.02);
    right.position.set(lerp(5.4, 12, out), lerp(-30, -0.6, kr), -5); right.rotation.set(0.03, -0.42, -0.02);
    left.scale.setScalar(1 - out * 0.1); right.scale.setScalar(1 - out * 0.1);
    const k = clamp((t - 35.5) / 5);
    setCam(v3(0, lerp(-1.0, -1.8, k), lerp(66, 60, SMOOTH(k)) - out * 18), v3(0, lerp(2.6, 2.2, k), 0), 30);
    scene.environmentRotation.set(0, lerp(-0.2, 0.25, k), 0);
    scene.environmentIntensity = 1 - out * 0.4;
    glowViolet.position.set(0, 0, -10); glowViolet.material.opacity = 0.45 * (1 - out); glowViolet.scale.setScalar(110);
    black = 1 - P(t, 35.5, .35) + P(t, 40.1, .4, SMOOTH);
  } else {
    hero.visible = false; black = 1;
  }

  // logo final
  const logo = $('logo'); logo.style.display = t >= 40.3 ? 'block' : 'none';
  if (t >= 40.3) {
    const ki = P(t, 40.55, 1.1);
    $('licon').style.transform = `scale(${.9 + .1 * ki})`; $('licon').style.opacity = ki; $('licon').style.filter = `blur(${(1 - ki) * 14}px)`;
    $('lglow').style.opacity = P(t, 40.5, 1.6, SMOOTH);
    const kw = P(t, 41.0, 1.0); $('lword').style.opacity = kw; $('lword').style.transform = `translateY(${(1 - kw) * 30}px)`; $('lword').style.filter = `blur(${(1 - kw) * 10}px)`;
  }
  copy('ltag', t, [41.6], 99);
  copy('lfoot', t, [42.3], 99);
  if (t >= 40.3) black = 0;

  // copy de planos
  copy('t1', t, [0.7, 2.5], 4.4);
  copy('t2', t, [6.9, 7.6], 9.0);
  copy('t3', t, [10.3, 11.1], 13.0);
  copy('t4', t, [15.2, 15.9], 18.5);
  copy('t5', t, [19.3, 23.1], 24.6);
  copy('t6', t, [25.4, 26.2], 30.5);
  copy('t7', t, [31.8, 32.9], 34.9);
  copy('t8', t, [36.0, 36.5, 37.0, 37.8], 39.6);

  $('scrim').style.opacity = P(t, 9.9, .8, SMOOTH) * (1 - P(t, 13.0, .5, SMOOTH));
  $('black').style.opacity = clamp(black);
  $('flash').style.opacity = clamp(flash);
  $('grain').style.backgroundPosition = `${(Math.floor(t * 30) * 137) % 512}px ${(Math.floor(t * 30) * 311) % 512}px`;
  renderer.render(scene, camera);
}

window.render = render;
if (Q.get('grain') === '0') document.getElementById('grain').style.display = 'none';
build().then(() => { render(0); window.READY = true; });
