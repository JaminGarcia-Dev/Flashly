// Uso:
//   node render.js frames "0.5,3.2,..." outdir      -> PNG de momentos sueltos
//   node render.js video <inicio> <fin> out.mp4     -> segmento H.264 a 30 fps
const { chromium } = require('playwright');
const { spawn } = require('child_process');
const fs = require('fs');

(async () => {
  const [, , mode, a, b, out] = process.argv;
  const browser = await chromium.launch({args:['--use-angle=swiftshader','--enable-unsafe-swiftshader','--ignore-gpu-blocklist']});
  const page = await browser.newPage({ viewport: { width: 1080, height: 1920 }, deviceScaleFactor: 1 });
  page.on('pageerror', e => console.error('PAGE ERROR', e.message));
  await page.goto('http://localhost:8766/index.html');
  await page.waitForFunction('window.READY === true', null, { timeout: 90000 });

  if (mode === 'frames') {
    fs.mkdirSync(b, { recursive: true });
    for (const ts of a.split(',')) {
      await page.evaluate(t => window.render(t), +ts);
      await page.screenshot({ path: `${b}/f_${ts}.png` });
    }
  } else {
    const fps = 30;
    const f0 = Math.round(+a * fps), f1 = Math.round(+b * fps);
    const tmp = out.replace(/\.mp4$/, '') + '.part.mp4';
    const ff = spawn('ffmpeg', ['-y', '-v', 'error', '-f', 'image2pipe', '-framerate', '30', '-c:v', 'mjpeg', '-i', '-',
      '-c:v', 'libx264', '-preset', 'medium', '-crf', '16', '-pix_fmt', 'yuv420p', '-r', '30', '-g', '30', tmp]);
    ff.stderr.on('data', d => process.stderr.write(d));
    const t0 = Date.now();
    for (let f = f0; f < f1; f++) {
      await page.evaluate(t => window.render(t), f / fps);
      const buf = await page.screenshot({ type: 'jpeg', quality: 92 });
      if (!ff.stdin.write(buf)) await new Promise(r => ff.stdin.once('drain', r));
    }
    ff.stdin.end();
    const code = await new Promise(r => ff.on('close', r));
    if (code === 0) fs.renameSync(tmp, out);
    console.log(`${out}: ${f1 - f0} frames, ${((Date.now() - t0) / 1000).toFixed(1)}s, ffmpeg=${code}`);
  }
  await browser.close();
})();
