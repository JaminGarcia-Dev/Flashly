#!/bin/bash
export NODE_PATH=$(npm root -g)
cd /home/claude/work/v2
w=$1; shift
for s in "$@"; do
  a=${s%:*}; b=${s#*:}
  name=$(printf "seg_%05.1f" $a)
  node render.js video $a $b out/$name.mp4
done
echo "DONE worker $w"
