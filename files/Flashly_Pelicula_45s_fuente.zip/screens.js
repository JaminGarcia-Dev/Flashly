// Pantallas de la app dibujadas en canvas 2D (900x1940), con el tema oscuro real de Flashly.
export const SW = 900, SH = 1940;
const C = {
  violet: '#7C5CFF', tint: '#9D85FF', magenta: '#C24FE0', pink: '#FF4F8B', flash: '#FFC53D', flashInk: '#2B2000',
  card: '#1C1C1E', elev: '#2C2C2E', sec: 'rgba(235,235,245,0.6)', ter: 'rgba(235,235,245,0.3)', fill: 'rgba(120,120,128,0.24)',
};
export const IMG = {};
const ICON_NAMES = ['zap', 'timer', 'camera', 'image', 'switch-camera', 'lock', 'map-pin', 'heart', 'users', 'calendar', 'message-circle', 'house', 'compass', 'user', 'send', 'search'];
const iconCache = {};

export async function loadAssets() {
  const names = ['icon', 'back0', 'back1', 'back2', 'back3', 'back4', 'back5', 'front0', 'front1', 'front2', 'front3', 'front4', 'front5',
    'avatar0', 'avatar1', 'avatar2', 'avatar3', 'avatar4', 'avatar5', 'avatar6', 'avatar7'];
  const load = (src) => new Promise((res) => { const i = new Image(); i.onload = () => res(i); i.onerror = () => res(i); i.src = src; });
  await Promise.all(names.map(async n => { IMG[n] = await load(`assets/${n}.png`); }));
  await Promise.all(ICON_NAMES.map(async n => { IMG['ic_' + n] = await load(`icons/${n}.svg`); }));
  await Promise.all(['600', '700', '800', '900'].map(w => document.fonts.load(`${w} 40px ID`)));
  await Promise.all(['400', '500', '600', '700'].map(w => document.fonts.load(`${w} 40px IT`)));
}

export function rr(ctx, x, y, w, h, r) {
  ctx.beginPath();
  ctx.moveTo(x + r, y); ctx.arcTo(x + w, y, x + w, y + h, r); ctx.arcTo(x + w, y + h, x, y + h, r);
  ctx.arcTo(x, y + h, x, y, r); ctx.arcTo(x, y, x + w, y, r); ctx.closePath();
}
function icon(ctx, name, x, y, s, color) {
  const key = name + color + s;
  if (!iconCache[key]) {
    const c = document.createElement('canvas'); c.width = c.height = s * 2;
    const g = c.getContext('2d'); g.drawImage(IMG['ic_' + name], 0, 0, s * 2, s * 2);
    g.globalCompositeOperation = 'source-in'; g.fillStyle = color; g.fillRect(0, 0, s * 2, s * 2);
    iconCache[key] = c;
  }
  ctx.drawImage(iconCache[key], x, y, s, s);
}
function cover(ctx, img, x, y, w, h, zoom = 1, oy = 0.5) {
  const ir = img.width / img.height, r = w / h;
  let sw, sh; if (ir > r) { sh = img.height; sw = sh * r; } else { sw = img.width; sh = sw / r; }
  sw /= zoom; sh /= zoom;
  ctx.drawImage(img, (img.width - sw) / 2, (img.height - sh) * oy, sw, sh, x, y, w, h);
}
function text(ctx, s, x, y, { size = 40, weight = 600, fam = 'IT', color = '#fff', align = 'left', ls = 0 } = {}) {
  ctx.font = `${weight} ${size}px ${fam}`; ctx.fillStyle = color; ctx.textAlign = align; ctx.textBaseline = 'alphabetic';
  if (ls) ctx.letterSpacing = ls + 'px'; else ctx.letterSpacing = '0px';
  ctx.fillText(s, x, y);
}
function wrap(ctx, s, x, y, maxW, lh, opts) {
  ctx.font = `${opts.weight || 400} ${opts.size || 36}px ${opts.fam || 'IT'}`;
  const words = s.split(' '); let line = '', yy = y;
  for (const w of words) {
    const test = line ? line + ' ' + w : w;
    if (ctx.measureText(test).width > maxW && line) { text(ctx, line, x, yy, opts); line = w; yy += lh; } else line = test;
  }
  if (line) text(ctx, line, x, yy, opts);
}
function avatar(ctx, n, x, y, s, ring = null) {
  ctx.save(); ctx.beginPath(); ctx.arc(x + s / 2, y + s / 2, s / 2, 0, Math.PI * 2); ctx.clip();
  ctx.drawImage(IMG['avatar' + (n % 8)], x, y, s, s); ctx.restore();
  if (ring) { ctx.lineWidth = ring[1]; ctx.strokeStyle = ring[0]; ctx.beginPath(); ctx.arc(x + s / 2, y + s / 2, s / 2, 0, Math.PI * 2); ctx.stroke(); }
}
export function statusBar(ctx, { dark = true, time = '13:47', showTime = true } = {}) {
  const col = dark ? '#fff' : '#000';
  if (showTime) text(ctx, time, 112, 92, { size: 38, weight: 600, color: col, align: 'center' });
  // señal, wifi y batería
  ctx.fillStyle = col;
  for (let i = 0; i < 4; i++) { rr(ctx, 650 + i * 16, 82 - (i + 1) * 7, 11, (i + 1) * 7, 3); ctx.fill(); }
  ctx.lineWidth = 3; ctx.strokeStyle = col; rr(ctx, 730, 60, 66, 32, 10); ctx.stroke();
  rr(ctx, 735, 65, 50, 22, 6); ctx.fill(); rr(ctx, 798, 70, 5, 12, 2); ctx.fill();
  ctx.fillStyle = '#000'; rr(ctx, 325, 30, 250, 74, 37); ctx.fill();   // isla
}
function tabBar(ctx, active = 0) {
  ctx.fillStyle = 'rgba(18,18,20,0.94)'; ctx.fillRect(0, 1760, SW, 180);
  ctx.fillStyle = 'rgba(84,84,88,0.6)'; ctx.fillRect(0, 1760, SW, 2);
  const items = [['house', 'Hoy'], ['compass', 'Descubrir'], ['user', 'Perfil']];
  items.forEach(([ic, l], i) => {
    const x = 150 + i * 300, col = i === active ? C.tint : 'rgba(235,235,245,0.55)';
    icon(ctx, ic, x - 28, 1786, 56, col);
    text(ctx, l, x, 1880, { size: 26, weight: 600, color: col, align: 'center' });
  });
  ctx.fillStyle = '#fff'; rr(ctx, 300, 1912, 300, 10, 5); ctx.fill();
}

/* ---------- pantalla de bloqueo ---------- */
export function drawLock(ctx, { minute = 47, notif = 0, wake = 1, glow = 0 } = {}) {
  const g = ctx.createLinearGradient(0, 0, SW * 0.4, SH);
  g.addColorStop(0, '#5B3FE0'); g.addColorStop(0.45, C.magenta); g.addColorStop(1, C.pink);
  ctx.fillStyle = g; ctx.fillRect(0, 0, SW, SH);
  const rg = ctx.createRadialGradient(SW * 0.2, SH * 0.15, 0, SW * 0.2, SH * 0.15, SW * 1.1);
  rg.addColorStop(0, 'rgba(255,255,255,0.18)'); rg.addColorStop(1, 'rgba(255,255,255,0)');
  ctx.fillStyle = rg; ctx.fillRect(0, 0, SW, SH);
  const dg = ctx.createLinearGradient(0, SH * 0.55, 0, SH);
  dg.addColorStop(0, 'rgba(10,0,30,0)'); dg.addColorStop(1, 'rgba(10,0,30,0.45)');
  ctx.fillStyle = dg; ctx.fillRect(0, 0, SW, SH);
  statusBar(ctx, { showTime: false });
  text(ctx, 'miércoles 4 de noviembre', SW / 2, 250, { size: 40, weight: 600, color: 'rgba(255,255,255,0.88)', align: 'center' });
  text(ctx, `13:${String(minute).padStart(2, '0')}`, SW / 2, 500, { size: 260, weight: 700, fam: 'ID', color: 'rgba(255,255,255,0.96)', align: 'center', ls: -6 });
  if (notif > 0) {
    ctx.save();
    const k = notif; ctx.globalAlpha = Math.min(1, k * 1.6);
    const y = 600 - (1 - k) * 140, s = 0.94 + 0.06 * k;
    ctx.translate(SW / 2, y + 120); ctx.scale(s, s); ctx.translate(-SW / 2, -(y + 120));
    ctx.shadowColor = 'rgba(30,0,60,0.45)'; ctx.shadowBlur = 50; ctx.shadowOffsetY = 18;
    ctx.fillStyle = 'rgba(255,255,255,0.94)'; rr(ctx, 36, y, SW - 72, 248, 58); ctx.fill();
    ctx.shadowColor = 'transparent';
    ctx.save(); rr(ctx, 70, y + 36, 110, 110, 26); ctx.clip(); ctx.drawImage(IMG.icon, 70, y + 36, 110, 110); ctx.restore();
    text(ctx, 'FLASHLY', 210, y + 66, { size: 29, weight: 600, color: 'rgba(60,60,67,0.6)', ls: 1 });
    text(ctx, 'ahora', SW - 76, y + 66, { size: 29, weight: 500, color: 'rgba(60,60,67,0.6)', align: 'right' });
    text(ctx, '¡Es ahora!', 210, y + 118, { size: 44, weight: 700, color: '#000' });
    ctx.font = '700 44px IT'; const tw = ctx.measureText('¡Es ahora!').width;
    icon(ctx, 'zap', 222 + tw, y + 80, 44, '#E8A400');
    wrap(ctx, 'Tienes 2 minutos para mostrar qué estás haciendo.', 210, y + 168, 590, 46, { size: 36, weight: 400, color: '#1c1c1e' });
    ctx.restore();
  }
  ctx.fillStyle = 'rgba(255,255,255,0.9)'; rr(ctx, 300, 1906, 300, 10, 5); ctx.fill();
  if (glow > 0) { ctx.fillStyle = `rgba(255,214,120,${glow * 0.5})`; ctx.fillRect(0, 0, SW, SH); }
  if (wake < 1) { ctx.fillStyle = `rgba(0,0,0,${1 - wake})`; ctx.fillRect(0, 0, SW, SH); }
}

/* ---------- inicio con la ventana abierta (anillo de 2 min) ---------- */
export function drawHome(ctx, { secs = 120, ring = 1, pulse = 0 } = {}) {
  ctx.fillStyle = '#000'; ctx.fillRect(0, 0, SW, SH);
  statusBar(ctx);
  text(ctx, 'Hoy', 56, 250, { size: 88, weight: 800, fam: 'ID', ls: -2 });
  text(ctx, 'Tu campus, hoy', 58, 312, { size: 36, weight: 500, color: C.sec });
  ctx.fillStyle = C.card; rr(ctx, 36, 370, SW - 72, 900, 64); ctx.fill();
  const ag = ctx.createRadialGradient(SW / 2, 820, 0, SW / 2, 820, 420);
  ag.addColorStop(0, 'rgba(255,197,61,0.16)'); ag.addColorStop(1, 'rgba(255,197,61,0)');
  ctx.fillStyle = ag; ctx.fillRect(36, 370, SW - 72, 900);
  text(ctx, '¡Es ahora!', SW / 2, 485, { size: 64, weight: 800, fam: 'ID', align: 'center', ls: -1.5 });
  const cx = SW / 2, cy = 800, R = 230;
  ctx.lineWidth = 34; ctx.lineCap = 'round';
  ctx.strokeStyle = C.elev; ctx.beginPath(); ctx.arc(cx, cy, R, 0, Math.PI * 2); ctx.stroke();
  const frac = (secs / 120) * ring;
  ctx.strokeStyle = C.flash; ctx.shadowColor = 'rgba(255,197,61,0.7)'; ctx.shadowBlur = 30;
  ctx.beginPath(); ctx.arc(cx, cy, R, -Math.PI / 2, -Math.PI / 2 + frac * Math.PI * 2); ctx.stroke();
  ctx.shadowBlur = 0; ctx.shadowColor = 'transparent';
  const s = 1 + pulse * 0.04;
  ctx.save(); ctx.translate(cx, cy + 50); ctx.scale(s, s);
  text(ctx, `${Math.floor(secs / 60)}:${String(secs % 60).padStart(2, '0')}`, 0, 0, { size: 156, weight: 800, fam: 'ID', align: 'center', ls: -3 });
  ctx.restore();
  text(ctx, 'para publicar', cx, cy + 110, { size: 34, weight: 600, color: C.sec, align: 'center' });
  ctx.fillStyle = C.flash; rr(ctx, 90, 1110, SW - 180, 116, 40); ctx.fill();
  icon(ctx, 'camera', 268, 1145, 46, C.flashInk);
  text(ctx, 'Tomar mi foto', 482, 1183, { size: 42, weight: 700, color: C.flashInk, align: 'center' });
  // vista previa bloqueada del feed
  ctx.save(); rr(ctx, 36, 1310, SW - 72, 600, 56); ctx.clip();
  ctx.filter = 'blur(28px)'; cover(ctx, IMG.back1, 36, 1310, SW - 72, 600); ctx.filter = 'none';
  ctx.fillStyle = 'rgba(0,0,0,0.35)'; ctx.fillRect(36, 1310, SW - 72, 600); ctx.restore();
  tabBar(ctx, 0);
}

/* ---------- cámara doble ---------- */
export function drawCamera(ctx, { zoom = 1, inset = 0, flash = 0, secs = 104, captured = 0 } = {}) {
  ctx.fillStyle = '#000'; ctx.fillRect(0, 0, SW, SH);
  cover(ctx, IMG.back2, 0, 0, SW, SH, zoom, 0.35);
  const g = ctx.createLinearGradient(0, 0, 0, SH);
  g.addColorStop(0, 'rgba(0,0,0,0.45)'); g.addColorStop(0.18, 'rgba(0,0,0,0)'); g.addColorStop(0.72, 'rgba(0,0,0,0)'); g.addColorStop(1, 'rgba(0,0,0,0.6)');
  ctx.fillStyle = g; ctx.fillRect(0, 0, SW, SH);
  statusBar(ctx);
  // pastilla de tiempo
  ctx.fillStyle = C.flash; rr(ctx, SW / 2 - 110, 150, 220, 70, 35); ctx.fill();
  icon(ctx, 'timer', SW / 2 - 84, 165, 40, C.flashInk);
  text(ctx, `${Math.floor(secs / 60)}:${String(secs % 60).padStart(2, '0')}`, SW / 2 + 22, 199, { size: 38, weight: 700, color: C.flashInk, align: 'center' });
  if (inset > 0) {
    ctx.save();
    const s = 0.6 + 0.4 * inset, x = 46, y = 250, w = 280, h = 373;
    ctx.globalAlpha = Math.min(1, inset * 3);
    ctx.translate(x + w / 2, y + h / 2); ctx.scale(s, s); ctx.translate(-(x + w / 2), -(y + h / 2));
    ctx.shadowColor = 'rgba(0,0,0,0.5)'; ctx.shadowBlur = 30; ctx.shadowOffsetY = 10;
    ctx.fillStyle = '#fff'; rr(ctx, x - 7, y - 7, w + 14, h + 14, 46); ctx.fill(); ctx.shadowColor = 'transparent';
    ctx.save(); rr(ctx, x, y, w, h, 40); ctx.clip(); cover(ctx, IMG.front0, x, y, w, h); ctx.restore();
    ctx.restore();
  }
  // controles
  if (captured < 1) {
    ctx.globalAlpha = 1 - captured;
    ctx.fillStyle = 'rgba(255,255,255,0.18)'; rr(ctx, 110, 1700, 110, 110, 28); ctx.fill();
    icon(ctx, 'image', 140, 1730, 50, '#fff');
    ctx.lineWidth = 12; ctx.strokeStyle = '#fff'; ctx.beginPath(); ctx.arc(SW / 2, 1755, 96, 0, Math.PI * 2); ctx.stroke();
    ctx.fillStyle = '#fff'; ctx.beginPath(); ctx.arc(SW / 2, 1755, 74, 0, Math.PI * 2); ctx.fill();
    ctx.fillStyle = 'rgba(255,255,255,0.18)'; ctx.beginPath(); ctx.arc(735, 1755, 55, 0, Math.PI * 2); ctx.fill();
    icon(ctx, 'switch-camera', 710, 1730, 50, '#fff');
    ctx.globalAlpha = 1;
  }
  if (captured > 0) {
    ctx.globalAlpha = captured;
    ctx.fillStyle = C.flash; rr(ctx, 90, 1690, SW - 180, 130, 44); ctx.fill();
    icon(ctx, 'send', 300, 1730, 50, C.flashInk);
    text(ctx, 'Publicar', 490, 1772, { size: 46, weight: 700, color: C.flashInk, align: 'center' });
    ctx.globalAlpha = 1;
  }
  if (flash > 0) { ctx.fillStyle = `rgba(255,255,255,${flash})`; ctx.fillRect(0, 0, SW, SH); }
}

/* ---------- feed (se dibuja una vez en un lienzo alto) ---------- */
const MOMENTS = [
  { n: 'Sofía Cruz', g: '10-A · Software', a: 1, bk: 0, fr: 1, pl: 'Biblioteca', tm: 'hace 1 min', lk: '3 me gusta', cap: 'Entre clases en la biblioteca' },
  { n: 'Luis Pérez', g: '7-B · Mecatrónica', a: 2, bk: 1, fr: 2, pl: 'Cancha', tm: 'hace 1 min', lk: '5 me gusta', cap: 'Torneo en la cancha' },
  { n: 'Diego Hernández', g: '10-B · Redes', a: 4, bk: 3, fr: 4, pl: 'Cafetería', tm: 'hace 2 min', lk: '2 me gusta', cap: 'Café antes del examen' },
];
let feedCanvas = null;
function buildFeed() {
  const c = document.createElement('canvas'); c.width = SW; c.height = 3600;
  const ctx = c.getContext('2d'); ctx.fillStyle = '#000'; ctx.fillRect(0, 0, SW, c.height);
  text(ctx, 'Hoy', 56, 250, { size: 88, weight: 800, fam: 'ID', ls: -2 });
  text(ctx, 'Tu campus, hoy · 14 momentos', 58, 312, { size: 36, weight: 500, color: C.sec });
  let y = 370;
  MOMENTS.forEach(m => {
    const cw = SW - 72, mh = cw * 1.25;
    ctx.fillStyle = C.card; rr(ctx, 36, y, cw, 150 + mh + 170, 58); ctx.fill();
    avatar(ctx, m.a, 70, y + 32, 92);
    text(ctx, m.n, 184, y + 76, { size: 38, weight: 600 });
    text(ctx, `${m.g} · ${m.tm}`, 184, y + 118, { size: 30, weight: 400, color: C.sec });
    ctx.save(); ctx.beginPath(); ctx.rect(36, y + 150, cw, mh); ctx.clip();
    cover(ctx, IMG['back' + m.bk], 36, y + 150, cw, mh);
    ctx.fillStyle = '#fff'; rr(ctx, 60, y + 174, 236, 314, 38); ctx.fill();
    ctx.save(); rr(ctx, 66, y + 180, 224, 302, 33); ctx.clip(); cover(ctx, IMG['front' + m.fr], 66, y + 180, 224, 302); ctx.restore();
    ctx.fillStyle = 'rgba(0,0,0,0.5)'; ctx.font = '500 30px IT'; const pw = ctx.measureText(m.pl).width;
    rr(ctx, 60, y + 150 + mh - 82, pw + 92, 58, 29); ctx.fill();
    icon(ctx, 'map-pin', 80, y + 150 + mh - 70, 32, '#fff');
    text(ctx, m.pl, 122, y + 150 + mh - 42, { size: 30, weight: 500 });
    ctx.restore();
    icon(ctx, 'heart', 70, y + 150 + mh + 30, 54, '#fff');
    text(ctx, m.lk, 146, y + 150 + mh + 70, { size: 32, color: C.sec, weight: 400 });
    text(ctx, m.cap, 70, y + 150 + mh + 132, { size: 34, weight: 400 });
    y += 150 + mh + 170 + 40;
  });
  feedCanvas = c;
}
export function drawFeed(ctx, { blur = 0, lock = 0, scroll = 0, tap = -1, dim = 0 } = {}) {
  if (!feedCanvas) buildFeed();
  ctx.fillStyle = '#000'; ctx.fillRect(0, 0, SW, SH);
  if (blur > 0.3) ctx.filter = `blur(${blur}px) saturate(${1 + blur / 60})`;
  ctx.drawImage(feedCanvas, 0, scroll, SW, SH, 0, 0, SW, SH);
  ctx.filter = 'none';
  if (dim > 0) { ctx.fillStyle = `rgba(0,0,0,${dim})`; ctx.fillRect(0, 0, SW, SH); }
  if (scroll > 40) { const hg = ctx.createLinearGradient(0, 0, 0, 170); hg.addColorStop(0, 'rgba(0,0,0,0.96)'); hg.addColorStop(0.7, 'rgba(0,0,0,0.85)'); hg.addColorStop(1, 'rgba(0,0,0,0)'); ctx.fillStyle = hg; ctx.fillRect(0, 0, SW, 170); }
  statusBar(ctx);
  if (lock > 0) {
    ctx.save(); ctx.globalAlpha = lock;
    const s = 0.92 + 0.08 * lock, y = 760;
    ctx.translate(SW / 2, y + 330); ctx.scale(s, s); ctx.translate(-SW / 2, -(y + 330));
    ctx.shadowColor = 'rgba(0,0,0,0.6)'; ctx.shadowBlur = 60; ctx.shadowOffsetY = 20;
    ctx.fillStyle = C.elev; rr(ctx, 50, y, SW - 100, 660, 64); ctx.fill(); ctx.shadowColor = 'transparent';
    const lg = ctx.createLinearGradient(380, y + 60, 520, y + 200);
    lg.addColorStop(0, C.violet); lg.addColorStop(0.5, C.magenta); lg.addColorStop(1, C.pink);
    ctx.fillStyle = lg; ctx.beginPath(); ctx.arc(SW / 2, y + 140, 72, 0, Math.PI * 2); ctx.fill();
    icon(ctx, 'lock', SW / 2 - 34, y + 106, 68, '#fff');
    text(ctx, 'Publica para ver', SW / 2, y + 300, { size: 56, weight: 800, fam: 'ID', align: 'center', ls: -1 });
    wrap(ctx, 'Los momentos de hoy se desbloquean cuando compartes el tuyo.', 110, y + 370, 680, 48, { size: 36, color: C.sec, weight: 400 });
    ctx.fillStyle = C.tint; rr(ctx, 100, y + 500, SW - 200, 116, 38); ctx.fill();
    icon(ctx, 'camera', 272, y + 534, 48, '#fff');
    text(ctx, 'Tomar mi foto', 484, y + 573, { size: 42, weight: 600, align: 'center' });
    if (tap >= 0 && tap < 1) {
      ctx.fillStyle = `rgba(255,255,255,${(1 - tap) * 0.5})`;
      ctx.beginPath(); ctx.arc(SW / 2, y + 558, 40 + tap * 120, 0, Math.PI * 2); ctx.fill();
    }
    ctx.restore();
  }
}

/* ---------- espera (al día siguiente) ---------- */
export function drawWaiting(ctx) {
  ctx.fillStyle = '#000'; ctx.fillRect(0, 0, SW, SH);
  statusBar(ctx, { time: '08:12' });
  text(ctx, 'Hoy', 56, 250, { size: 88, weight: 800, fam: 'ID', ls: -2 });
  text(ctx, 'Tu campus, hoy', 58, 312, { size: 36, weight: 500, color: C.sec });
  ctx.fillStyle = C.card; rr(ctx, 36, 370, SW - 72, 760, 64); ctx.fill();
  ctx.lineWidth = 30; ctx.strokeStyle = C.elev; ctx.beginPath(); ctx.arc(SW / 2, 640, 170, 0, Math.PI * 2); ctx.stroke();
  icon(ctx, 'timer', SW / 2 - 70, 570, 140, 'rgba(235,235,245,0.55)');
  wrap(ctx, 'El flash de hoy aún no suena', 110, 920, 680, 66, { size: 56, weight: 800, fam: 'ID', ls: -1 });
  wrap(ctx, 'Llegará un aviso entre las 9:00 y las 18:00. Tendrás 2 minutos para publicar.', 110, 1050, 680, 46, { size: 34, color: C.sec, weight: 400 });
  tabBar(ctx, 0);
}

/* ---------- descubrir ---------- */
export function drawDiscover(ctx) {
  ctx.fillStyle = '#000'; ctx.fillRect(0, 0, SW, SH);
  statusBar(ctx);
  text(ctx, 'Descubrir', 56, 250, { size: 88, weight: 800, fam: 'ID', ls: -2 });
  text(ctx, 'Tu campus, hoy', 58, 312, { size: 36, weight: 500, color: C.sec });
  text(ctx, 'Lugares con movimiento', 56, 410, { size: 42, weight: 700 });
  const places = [['Biblioteca', 12, 1, '#7C5CFF'], ['Cafetería', 23, 3, '#FF9500'], ['Cancha', 8, 6, '#34C759'], ['Laboratorios', 5, 5, '#30B0C7']];
  places.forEach(([l, n, a, col], i) => {
    const x = 36 + (i % 2) * 422, y = 450 + Math.floor(i / 2) * 290;
    ctx.fillStyle = C.card; rr(ctx, x, y, 406, 270, 48); ctx.fill();
    ctx.fillStyle = col; ctx.beginPath(); ctx.arc(x + 70, y + 72, 40, 0, Math.PI * 2); ctx.fill();
    icon(ctx, 'map-pin', x + 50, y + 52, 40, '#fff');
    text(ctx, l, x + 34, y + 176, { size: 38, weight: 700 });
    text(ctx, `${n} momentos hoy`, x + 34, y + 226, { size: 30, color: C.sec, weight: 400 });
    for (let k = 2; k >= 0; k--) avatar(ctx, a + k, x + 260 + k * 40, y + 44, 64, ['#1C1C1E', 5]);
  });
  text(ctx, 'Personas', 56, 1100, { size: 42, weight: 700 });
  text(ctx, 'Primero, los de tu grupo', 56, 1148, { size: 30, color: C.sec, weight: 400 });
  ['Sofía', 'Luis', 'Mariana', 'Diego', 'Carla'].forEach((n, i) => {
    const x = 56 + i * 166;
    avatar(ctx, i + 1, x, 1190, 130, i < 3 ? [C.flash, 6] : null);
    text(ctx, n, x + 65, 1370, { size: 28, weight: 500, align: 'center' });
  });
  text(ctx, 'Eventos', 56, 1480, { size: 42, weight: 700 });
  ctx.save(); rr(ctx, 36, 1510, SW - 72, 230, 48); ctx.clip();
  cover(ctx, IMG.back4, 36, 1510, SW - 72, 230, 1, 0.4);
  const eg = ctx.createLinearGradient(0, 1510, 0, 1740); eg.addColorStop(0, 'rgba(0,0,0,0.1)'); eg.addColorStop(1, 'rgba(0,0,0,0.7)');
  ctx.fillStyle = eg; ctx.fillRect(36, 1510, SW - 72, 230);
  text(ctx, 'Torneo relámpago de fútbol', 70, 1660, { size: 38, weight: 700 });
  text(ctx, 'Cancha · Hoy, 16:00', 70, 1708, { size: 30, color: 'rgba(255,255,255,0.8)', weight: 500 });
  ctx.restore();
  tabBar(ctx, 1);
}

/* ---------- chat del campus ---------- */
export function drawChat(ctx) {
  ctx.fillStyle = '#000'; ctx.fillRect(0, 0, SW, SH);
  statusBar(ctx);
  text(ctx, 'Chat del campus', SW / 2, 200, { size: 44, weight: 700, align: 'center' });
  text(ctx, '128 en línea', SW / 2, 248, { size: 30, color: C.sec, weight: 400, align: 'center' });
  ctx.fillStyle = 'rgba(84,84,88,0.6)'; ctx.fillRect(0, 290, SW, 2);
  const msgs = [
    [0, 1, '¿Alguien en la biblioteca?'], [1, null, 'Yo, segundo piso'], [0, 3, 'Hoy hay torneo en la cancha a las 4'],
    [0, 5, '¿Quién se apunta?'], [1, null, '¡Vamos! Llevo a mi grupo'], [0, 2, 'Nos vemos ahí'],
  ];
  let y = 360;
  msgs.forEach(([me, a, s]) => {
    ctx.font = '400 36px IT'; const w = Math.min(560, ctx.measureText(s).width + 64);
    if (me) {
      ctx.fillStyle = C.tint; rr(ctx, SW - 40 - w, y, w, 92, 46); ctx.fill();
      text(ctx, s, SW - 40 - w + 32, y + 58, { size: 36, weight: 400 });
    } else {
      avatar(ctx, a, 36, y + 12, 72);
      ctx.fillStyle = '#26252A'; rr(ctx, 124, y, w, 92, 46); ctx.fill();
      text(ctx, s, 156, y + 58, { size: 36, weight: 400 });
    }
    y += 140;
  });
  ctx.fillStyle = '#1C1C1E'; rr(ctx, 36, 1700, SW - 180, 100, 50); ctx.fill();
  text(ctx, 'Escribe al campus…', 80, 1763, { size: 34, color: C.ter, weight: 400 });
  ctx.fillStyle = C.tint; ctx.beginPath(); ctx.arc(SW - 86, 1750, 50, 0, Math.PI * 2); ctx.fill();
  icon(ctx, 'send', SW - 110, 1726, 48, '#fff');
  ctx.fillStyle = '#fff'; rr(ctx, 300, 1906, 300, 10, 5); ctx.fill();
}
