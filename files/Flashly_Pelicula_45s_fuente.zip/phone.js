// Teléfono genérico de gama alta, construido en código (sin logotipos ni diseño de una marca real).
import * as THREE from 'three';

export const DIM = { w: 7.1, h: 14.7, d: 0.82, r: 1.18 };

function rrShape(w, h, r) {
  const s = new THREE.Shape();
  const x = -w / 2, y = -h / 2;
  s.moveTo(x + r, y);
  s.lineTo(x + w - r, y); s.quadraticCurveTo(x + w, y, x + w, y + r);
  s.lineTo(x + w, y + h - r); s.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
  s.lineTo(x + r, y + h); s.quadraticCurveTo(x, y + h, x, y + h - r);
  s.lineTo(x, y + r); s.quadraticCurveTo(x, y, x + r, y);
  return s;
}

// Esquinas tipo "squircle" (continuas) para pantalla y vidrio.
function squircle(w, h, r, n = 4.2) {
  const s = new THREE.Shape();
  const seg = 18;
  const corner = (cx, cy, a0) => {
    for (let i = 0; i <= seg; i++) {
      const a = a0 + (i / seg) * Math.PI / 2;
      const c = Math.cos(a), sn = Math.sin(a);
      const px = cx + r * Math.sign(c) * Math.pow(Math.abs(c), 2 / n);
      const py = cy + r * Math.sign(sn) * Math.pow(Math.abs(sn), 2 / n);
      if (i === 0 && a0 === 0) s.moveTo(px, py); else s.lineTo(px, py);
    }
  };
  corner(w / 2 - r, h / 2 - r, 0);
  corner(-w / 2 + r, h / 2 - r, Math.PI / 2);
  corner(-w / 2 + r, -h / 2 + r, Math.PI);
  corner(w / 2 - r, -h / 2 + r, Math.PI * 1.5);
  s.closePath();
  return s;
}

function planarUV(geo, w, h) {
  const p = geo.attributes.position, uv = geo.attributes.uv;
  for (let i = 0; i < p.count; i++) uv.setXY(i, (p.getX(i) + w / 2) / w, (p.getY(i) + h / 2) / h);
  uv.needsUpdate = true;
  return geo;
}

let BAND = null;
function bandTexture() {
  if (BAND) return BAND;
  const c = document.createElement('canvas'); c.width = 1024; c.height = 8;
  const g = c.getContext('2d'); const gr = g.createLinearGradient(0, 0, 1024, 0);
  [[0, 0], [0.36, 0], [0.44, 0.10], [0.485, 0.55], [0.5, 0.95], [0.515, 0.55], [0.56, 0.10], [0.64, 0], [1, 0]]
    .forEach(([o, a]) => gr.addColorStop(o, `rgba(255,255,255,${a})`));
  g.fillStyle = gr; g.fillRect(0, 0, 1024, 8);
  BAND = new THREE.CanvasTexture(c); BAND.colorSpace = THREE.SRGBColorSpace;
  return BAND;
}

export function makePhone(screenTexture, opts = {}) {
  const LITE = new URLSearchParams(location.search).get('lite') === '1';
  const PM = (o) => { if (!LITE) return new THREE.MeshPhysicalMaterial(o); const { clearcoat, clearcoatRoughness, sheen, sheenColor, sheenRoughness, iridescence, iridescenceIOR, iridescenceThicknessRange, ...rest } = o; return new THREE.MeshStandardMaterial(rest); };
  const { w, h, d, r } = DIM;
  const g = new THREE.Group();

  // Marco de titanio
  const bevel = 0.2, bt = 0.22;
  const frameGeo = new THREE.ExtrudeGeometry(rrShape(w - 2 * bevel, h - 2 * bevel, r - bevel), {
    depth: d - 2 * bt, bevelEnabled: true, bevelThickness: bt, bevelSize: bevel, bevelSegments: 10, curveSegments: 48,
  });
  frameGeo.translate(0, 0, -(d - 2 * bt) / 2);
  frameGeo.computeVertexNormals();
  const frameMat = PM({
    color: opts.frame ?? 0x4a4650, metalness: 1, roughness: 0.26, clearcoat: 0.4, clearcoatRoughness: 0.2, envMapIntensity: 1.25,
  });
  const frame = new THREE.Mesh(frameGeo, frameMat);
  g.add(frame);

  // Vidrio frontal (negro brillante) y pantalla
  const gw = w - 0.16, gh = h - 0.16;
  const glassGeo = new THREE.ShapeGeometry(squircle(gw, gh, r - 0.07), 24);
  const glass = new THREE.Mesh(glassGeo, PM({ color: 0x020203, roughness: 0.08, metalness: 0, clearcoat: 1, clearcoatRoughness: 0.03 }));
  glass.position.z = d / 2 + 0.002;
  g.add(glass);

  const sw = w - 0.52, sh = h - 0.52;
  const screenGeo = planarUV(new THREE.ShapeGeometry(squircle(sw, sh, r - 0.26), 24), sw, sh);
  const screenMat = new THREE.MeshBasicMaterial({ map: screenTexture, toneMapped: false, color: 0xffffff });
  const screen = new THREE.Mesh(screenGeo, screenMat);
  screen.position.z = d / 2 + 0.004;
  g.add(screen);

  // Reflejo del vidrio sobre la pantalla (Fresnel dieléctrico, mezcla aditiva)
  const refl = new THREE.Mesh(glassGeo, new THREE.MeshStandardMaterial({
    color: 0x000000, roughness: 0.04, metalness: 0, transparent: true, blending: THREE.AdditiveBlending, depthWrite: false, envMapIntensity: 1.6,
  }));
  refl.position.z = d / 2 + 0.006;
  if (!LITE) g.add(refl);

  // Barrido de brillo (reflejo en movimiento) sobre el vidrio frontal y trasero
  const mkSweep = (z, flip) => {
    const tex = bandTexture().clone(); tex.needsUpdate = true;
    tex.wrapS = tex.wrapT = THREE.ClampToEdgeWrapping; tex.center.set(0.5, 0.5); tex.rotation = -0.5; tex.offset.x = -1;
    const m = new THREE.Mesh(planarUV(new THREE.ShapeGeometry(squircle(gw, gh, r - 0.07), 24), gw, gh),
      new THREE.MeshBasicMaterial({ map: tex, transparent: true, blending: THREE.AdditiveBlending, depthWrite: false, toneMapped: false, opacity: 0 }));
    m.position.z = z; if (flip) m.rotation.y = Math.PI; g.add(m); return m;
  };
  const sweep = mkSweep(d / 2 + 0.009, false);
  const sweepBack = mkSweep(-d / 2 - 0.009, true);

  // Parte trasera: vidrio esmerilado
  const back = new THREE.Mesh(glassGeo, PM({ color: opts.back ?? 0x2a2238, roughness: 0.36, metalness: 0.0, clearcoat: 0.6, clearcoatRoughness: 0.5, sheen: 0.4, sheenColor: new THREE.Color(0x7c5cff), sheenRoughness: 0.6 }));
  back.position.z = -d / 2 - 0.002; back.rotation.y = Math.PI;
  g.add(back);

  // Módulo de cámara: píldora vertical con dos lentes y flash
  const camG = new THREE.Group();
  const pill = new THREE.Mesh(
    new THREE.ExtrudeGeometry(rrShape(1.75, 3.55, 0.86), { depth: 0.08, bevelEnabled: true, bevelThickness: 0.06, bevelSize: 0.06, bevelSegments: 6, curveSegments: 32 }),
    PM({ color: 0x15121c, roughness: 0.18, metalness: 0.2, clearcoat: 1, clearcoatRoughness: 0.05 }));
  camG.add(pill);
  const ringMat = PM({ color: 0x8a8590, metalness: 1, roughness: 0.18 });
  const lensMat = PM({ color: 0x050508, roughness: 0.02, metalness: 0.1, clearcoat: 1, clearcoatRoughness: 0, iridescence: 0.8, iridescenceIOR: 1.6, iridescenceThicknessRange: [200, 600] });
  [0.82, -0.82].forEach(y => {
    const ring = new THREE.Mesh(new THREE.CylinderGeometry(0.66, 0.68, 0.14, 48), ringMat);
    ring.rotation.x = Math.PI / 2; ring.position.set(0, y, 0.2); camG.add(ring);
    const lens = new THREE.Mesh(new THREE.CircleGeometry(0.54, 48), lensMat);
    lens.position.set(0, y, 0.272); camG.add(lens);
    const inner = new THREE.Mesh(new THREE.RingGeometry(0.18, 0.24, 48), new THREE.MeshBasicMaterial({ color: 0x1e1a2a }));
    inner.position.set(0, y, 0.274); camG.add(inner);
  });
  const flashMat = new THREE.MeshBasicMaterial({ color: 0xfff1d0, toneMapped: false });
  const flash = new THREE.Mesh(new THREE.CircleGeometry(0.16, 32), flashMat);
  flash.position.set(0.58, 0, 0.16); camG.add(flash);
  camG.position.set(w / 2 - 1.55, h / 2 - 2.55, -d / 2 - 0.004);
  camG.rotation.y = Math.PI;
  g.add(camG);

  // Botones laterales
  const btnMat = PM({ color: 0x55505c, metalness: 1, roughness: 0.3 });
  const btn = (x, y, len) => {
    const m = new THREE.Mesh(new THREE.CapsuleGeometry(0.07, len, 6, 12), btnMat);
    m.position.set(x, y, 0); g.add(m);
  };
  btn(w / 2 + 0.02, 2.6, 1.8);
  btn(-w / 2 - 0.02, 3.4, 0.9); btn(-w / 2 - 0.02, 2.1, 0.9);

  g.userData = { screenMat, flashMat, frameMat, screen, refl, camG, sweep, sweepBack };
  return g;
}
