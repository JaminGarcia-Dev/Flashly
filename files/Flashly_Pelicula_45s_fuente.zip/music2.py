"""Pista de 45 s (120 BPM) para la película de producto de Flashly, sincronizada a los planos."""
import numpy as np
from scipy import signal
from scipy.io import wavfile

SR = 44100
DUR = 45.0
N = int(SR * DUR)
rng = np.random.default_rng(42)
L = np.zeros(N)
R = np.zeros(N)
BUS_REV = np.zeros((2, N))        # envío a reverb
DUCK_KEYS = []                     # tiempos de bombo para el sidechain
PAD = np.zeros((2, N)); BASS = np.zeros((2, N)); ARP = np.zeros((2, N))


def mf(m):
    return 440.0 * 2 ** ((m - 69) / 12)


def tt(d):
    return np.arange(int(SR * d)) / SR


def bp(x, lo, hi, order=2):
    sos = signal.butter(order, [lo, hi], btype='band', fs=SR, output='sos')
    return signal.sosfilt(sos, x)


def lp(x, fc, order=2):
    sos = signal.butter(order, fc, btype='low', fs=SR, output='sos')
    return signal.sosfilt(sos, x)


def hp(x, fc, order=2):
    sos = signal.butter(order, fc, btype='high', fs=SR, output='sos')
    return signal.sosfilt(sos, x)


def put(at, x, g=1.0, pan=0.0, rev=0.0, bus=None):
    """Suma una señal mono en el instante `at` (s) con paneo (-1..1) y envío de reverb."""
    i0 = int(round(at * SR))
    if i0 >= N:
        return
    if i0 < 0:
        x = x[-i0:]; i0 = 0
    x = x[: N - i0] * g
    gl = np.sqrt(0.5 * (1 - pan)); gr = np.sqrt(0.5 * (1 + pan))
    if bus is None:
        L[i0:i0 + len(x)] += x * gl; R[i0:i0 + len(x)] += x * gr
    else:
        bus[0, i0:i0 + len(x)] += x * gl; bus[1, i0:i0 + len(x)] += x * gr
    if rev:
        BUS_REV[0, i0:i0 + len(x)] += x * gl * rev; BUS_REV[1, i0:i0 + len(x)] += x * gr * rev


# ---------- instrumentos ----------
def kick(big=False):
    t = tt(0.9 if big else 0.45)
    f = 52 + 120 * np.exp(-t / 0.025)
    ph = 2 * np.pi * np.cumsum(f) / SR
    x = np.sin(ph) * np.exp(-t / (0.3 if big else 0.13))
    click = rng.normal(0, 1, len(t)) * np.exp(-t / 0.003) * 0.5
    return np.tanh(1.8 * (x + hp(click, 2000))) * 0.95


def sub_boom():
    t = tt(2.2)
    f = 40 + 40 * np.exp(-t / 0.15)
    return np.sin(2 * np.pi * np.cumsum(f) / SR) * np.exp(-t / 0.7)


def clap():
    t = tt(0.35); x = np.zeros(len(t))
    for k, off in enumerate([0, 0.011, 0.022]):
        i = int(off * SR)
        n = rng.normal(0, 1, len(t) - i) * np.exp(-tt((len(t) - i) / SR) / (0.012 if k < 2 else 0.13))
        x[i:] += n
    return bp(x, 900, 4200) * 1.4


def snare():
    t = tt(0.25)
    body = np.sin(2 * np.pi * 190 * t) * np.exp(-t / 0.05)
    nz = bp(rng.normal(0, 1, len(t)), 1500, 8000) * np.exp(-t / 0.08)
    return body * 0.6 + nz * 0.9


def hat(open_=False):
    t = tt(0.3 if open_ else 0.06)
    return hp(rng.normal(0, 1, len(t)), 7500, 4) * np.exp(-t / (0.12 if open_ else 0.018))


def crash(d=2.4):
    t = tt(d)
    x = hp(rng.normal(0, 1, len(t)), 3800, 2) * np.exp(-t / 0.75)
    return x * (1 - np.exp(-t / 0.002))


def riser(d, f0=300, f1=7000):
    t = tt(d)
    nz = rng.normal(0, 1, len(t))
    out = np.zeros(len(t)); seg = 2048
    for i in range(0, len(t), seg):
        k = i / len(t); fc = f0 * (f1 / f0) ** k
        out[i:i + seg] = bp(nz[i:i + seg], fc * 0.7, min(fc * 1.4, 16000), 1)
    tone = np.sin(2 * np.pi * np.cumsum(200 * (6 ** (t / d))) / SR) * 0.25
    env = (t / d) ** 2.2
    return (out * 1.6 + tone) * env


def whoosh(d=0.45, up=True):
    t = tt(d)
    nz = rng.normal(0, 1, len(t)); out = np.zeros(len(t)); seg = 1024
    for i in range(0, len(t), seg):
        k = i / len(t); k = k if up else 1 - k
        fc = 400 * (12 ** k)
        out[i:i + seg] = bp(nz[i:i + seg], fc * 0.6, min(fc * 1.6, 16000), 1)
    env = np.sin(np.pi * np.clip(t / d, 0, 1)) ** 1.5
    return out * env * 1.5


def bell(m, d=0.6, bright=0.3):
    t = tt(d); f = mf(m)
    x = np.sin(2 * np.pi * f * t) + bright * np.sin(2 * np.pi * f * 2.0 * t) * np.exp(-t / 0.1) + 0.12 * np.sin(2 * np.pi * f * 3.01 * t)
    return x * np.exp(-t / (d / 3.5)) * (1 - np.exp(-t / 0.002))


def tick():
    t = tt(0.05)
    return (np.sin(2 * np.pi * 2300 * t) * 0.7 + hp(rng.normal(0, 1, len(t)), 3000) * 0.3) * np.exp(-t / 0.008)


def thwack():
    t = tt(0.3)
    nz = lp(rng.normal(0, 1, len(t)), 2500) * np.exp(-t / 0.04)
    th = np.sin(2 * np.pi * np.cumsum(90 + 140 * np.exp(-t / 0.02)) / SR) * np.exp(-t / 0.09)
    return nz * 0.9 + th


def bloop(f0=500, f1=1100, d=0.14):
    t = tt(d)
    f = f0 + (f1 - f0) * (1 - np.exp(-t / 0.03))
    return np.sin(2 * np.pi * np.cumsum(f) / SR) * np.exp(-t / 0.05) * (1 - np.exp(-t / 0.002))


def saw(f, d, detune=0.0):
    t = tt(d)
    return signal.sawtooth(2 * np.pi * f * (1 + detune) * t + rng.uniform(0, 6.28))


# ---------- armonía: C – G – Am – F (compases de 2 s desde 6.0) ----------
CH = {'C': [55, 60, 64, 67, 74], 'G': [55, 59, 62, 67, 71], 'Am': [57, 60, 64, 69, 71], 'F': [53, 57, 60, 65, 67], 'Am9': [57, 60, 64, 67, 71]}
ROOT = {'C': 48, 'G': 43, 'Am': 45, 'F': 41, 'Am9': 45}
PROG = [(0, 6.0, 'Am9')]
cyc = ['C', 'G', 'Am', 'F']
t0 = 6.0; i = 0
while t0 < 31.0 - 1e-6:
    PROG.append((t0, min(t0 + 2, 31.0), cyc[i % 4])); t0 += 2; i += 1
PROG += [(31.0, 33.25, 'Am9'), (33.25, 35.5, 'F'), (35.5, 37.5, 'C'), (37.5, 39.5, 'G'), (39.5, 40.5, 'F'), (40.5, 45.0, 'C')]


def chord_at(t):
    for a, b, c in PROG:
        if a <= t < b:
            return c
    return 'C'


def pad_chord(a, b, c, g=0.16):
    d = b - a + 0.6
    t = tt(d); x = np.zeros(len(t))
    for m in CH[c][:4]:
        for dt in (-0.006, 0.0, 0.007):
            x += saw(mf(m), d, dt)
    x = lp(x, 1600)
    env = np.minimum(1, t / 0.35) * np.clip((d - t) / 0.6, 0, 1)
    put(a, x * env, g / 5, 0.0, rev=0.55, bus=PAD)


for a, b, c in PROG:
    pad_chord(a, b, c, 0.2 if a >= 40.5 else 0.16)


def piano(m, d=1.6, g=0.1, pan=0.0):
    t = tt(d); f = mf(m)
    x = (np.sin(2 * np.pi * f * t) + 0.45 * np.sin(2 * np.pi * 2 * f * t) * np.exp(-t / 0.35) + 0.2 * np.sin(2 * np.pi * 3.01 * f * t) * np.exp(-t / 0.2))
    x *= np.exp(-t / 0.55) * (1 - np.exp(-t / 0.003))
    return x


def groove(a, b, arp=True, bass=True, hats=True, big=False):
    t = a
    while t < b - 1e-6:
        beat = int(round((t - 6.0) / 0.5)) % 4
        put(t, kick(), 0.66 if not big else 0.72); DUCK_KEYS.append(t)
        if beat in (1, 3):
            put(t, clap(), 0.5, 0.0, rev=0.3)
        if hats:
            put(t + 0.25, hat(big), 0.11 if not big else 0.14, 0.25)
            for s_ in (0.125, 0.375):
                put(t + s_, hat(), 0.07, -0.3)
        if bass:
            c = chord_at(t + 0.25); f = mf(ROOT[c])
            note = saw(f, 0.22) * 0.6 + saw(f, 0.22, 0.004) * 0.6 + np.sin(2 * np.pi * f / 2 * tt(0.22)) * 0.8
            env = np.minimum(1, tt(0.22) / 0.005) * np.exp(-tt(0.22) / 0.16)
            put(t + 0.25, lp(note, 1100) * env, 0.42, 0.0, bus=BASS)
        t += 0.5
    if arp:
        t = a; k = 0
        while t < b - 1e-6:
            c = chord_at(t); notes = CH[c]
            m = notes[[0, 2, 1, 3, 4, 2, 3, 1][k % 8]] + 12
            d = 0.2
            x = (signal.square(2 * np.pi * mf(m) * tt(d), 0.3) * 0.5 + saw(mf(m), d) * 0.5)
            x = lp(x, 3000) * np.exp(-tt(d) / 0.07) * np.minimum(1, tt(d) / 0.003)
            pan = 0.35 if k % 2 else -0.35
            put(t, x, 0.14, pan, rev=0.3, bus=ARP)
            put(t + 0.1875, x, 0.055, -pan, bus=ARP)
            t += 0.125; k += 1


# Intro 0–6: notas de piano espaciadas, pulso suave, tic-tac desde 5.0
for at, m in [(0.0, 69), (0.75, 72), (1.5, 76), (2.5, 74), (3.25, 72), (4.0, 69)]:
    put(at, piano(m, 2.0), 0.13, -0.2 + 0.08 * (m - 69) / 3, rev=0.6)
    put(at, piano(m - 12, 2.0), 0.07, 0, rev=0.5)
for i in range(10):
    put(0.5 * i + 0.25, np.sin(2 * np.pi * 55 * tt(0.4)) * np.exp(-tt(0.4) / 0.15), 0.18)  # pulso sub
put(0.7, whoosh(0.8), 0.05, -0.3); put(2.5, whoosh(0.8), 0.05, 0.3)
put(4.5, whoosh(0.5, False), 0.08)
for i in range(4):
    put(5.0 + 0.25 * i, tick(), 0.18 + 0.05 * i, 0.15 if i % 2 else -0.15)
put(5.0, riser(1.0, 400, 9000), 0.26, 0, rev=0.2)

# 6.0 drop con la notificación
put(6.0, kick(True), 0.9); put(6.0, sub_boom(), 0.4); put(6.0, crash(), 0.28, 0.1, rev=0.4)
put(6.0, bell(88, 0.6), 0.16, 0.1, rev=0.3); put(6.09, bell(93, 0.7), 0.14, 0.1, rev=0.35)
groove(6.0, 31.0)

# S3: ola de teléfonos (campanitas ascendentes)
pent = [72, 74, 76, 79, 81, 84, 86, 88, 91, 93, 96]
for k in range(22):
    at = 9.9 + k * 0.11
    put(at, bell(pent[k % len(pent)] + (12 if k > 10 else 0), 0.4, 0.2), 0.03 + 0.002 * k, ((k * 37) % 9) / 4.5 - 1, rev=0.4)
put(9.5, whoosh(1.2, False), 0.1)
put(13.25, whoosh(0.75), 0.16)
# S4: tic del reloj en cada pulso
for i in range(10):
    put(14.5 + 0.5 * i, tick(), 0.12, 0.2 if i % 2 else -0.2)
# S5: giro, flash, obturador
put(19.0, whoosh(1.0), 0.12); put(21.5, whoosh(1.0, False), 0.12)
put(20.98, kick(True), 0.7); put(20.98, crash(1.6), 0.2, 0, rev=0.4)
t_ = tt(0.3)
put(20.98, hp(rng.normal(0, 1, len(t_)), 5000) * np.exp(-t_ / 0.06) + np.sin(2 * np.pi * np.cumsum(3200 - 2200 * t_ / 0.3) / SR) * np.exp(-t_ / 0.07) * 0.35, 0.25, 0, rev=0.3)
put(22.65, tick(), 0.25); put(22.75, thwack(), 0.1)
put(22.98, hp(rng.normal(0, 1, len(t_)), 5000) * np.exp(-t_ / 0.05), 0.2, 0, rev=0.3)
put(23.05, bloop(400, 900), 0.18)
put(23.6, bloop(500, 1000), 0.12)
# S6: toque y desbloqueo
put(27.4, tick(), 0.2)
for k, m in enumerate((81, 84, 88, 93)):
    put(27.75 + 0.06 * k, bell(m, 0.8, 0.35), 0.08, -0.3 + 0.2 * k, rev=0.45)
put(27.75, crash(1.8), 0.14, 0, rev=0.4); put(27.75, whoosh(0.6), 0.1)

# S7 31–35.5: pausa, sin batería, reloj lento y subida
put(31.0, sub_boom(), 0.25); put(31.0, crash(2.0), 0.14, -0.1, rev=0.5)
for i in range(9):
    put(31.0 + 0.5 * i, tick(), 0.09, 0.15 if i % 2 else -0.15)
for at, m in [(31.0, 69), (32.0, 67), (33.25, 65), (34.25, 64)]:
    put(at, piano(m, 2.2), 0.11, 0, rev=0.65); put(at, piano(m - 12, 2.2), 0.06, 0, rev=0.5)
t_, step = 34.5, 0.125
while t_ < 35.48:
    put(t_, snare(), 0.1 + 0.28 * (t_ - 34.5), (rng.random() - 0.5) * 0.3, rev=0.2); t_ += step; step = max(0.0625, step * 0.9)
put(34.4, riser(1.1, 400, 10000), 0.28, 0, rev=0.2)

# S8 35.5–40.1: coro final
put(35.5, kick(True), 0.92); put(35.5, sub_boom(), 0.35); put(35.5, crash(), 0.28, 0.1, rev=0.45)
groove(35.5, 40.0, big=True)
for k, at in enumerate((35.5, 35.68, 35.8)):
    put(at, whoosh(0.5), 0.06, [-0.4, 0, 0.4][k])
for k, at in enumerate((36.0, 36.5, 37.0)):
    put(at, bell(84 + 3 * k, 0.6, 0.3), 0.06, 0, rev=0.4)
put(39.6, riser(0.9, 600, 12000), 0.24)

# 40.5 final: golpe y acorde abierto que se desvanece
put(40.5, kick(True), 0.95); put(40.5, sub_boom(), 0.42); put(40.5, crash(3.5), 0.3, 0, rev=0.6)
for m in (60, 64, 67, 72, 76):
    put(40.5, bell(m + 12, 3.2, 0.4), 0.05, (m - 68) / 10, rev=0.7)
    put(40.5, piano(m, 4.0), 0.06, (m - 68) / 12, rev=0.6)
put(41.0, piano(79, 3.0), 0.06, 0.2, rev=0.7)

# ---------- sidechain, filtros y reverb ----------
tN = np.arange(N) / SR
duck = np.ones(N)
for k in DUCK_KEYS:
    i0 = int(k * SR); i1 = min(N, i0 + int(0.45 * SR)); seg = tN[i0:i1] - k
    duck[i0:i1] = np.minimum(duck[i0:i1], 1 - 0.55 * np.exp(-seg / 0.11))
pad_lp = np.stack([lp(PAD[0], 450), lp(PAD[1], 450)])
mix_k = np.ones(N)
m_ = tN < 6.0; mix_k[m_] = 0.0
m_ = (tN >= 31.0) & (tN < 35.5); mix_k[m_] = np.clip(0.15 + 0.85 * ((tN[m_] - 31.0) / 4.5) ** 3, 0, 1)
pad_mix = PAD * mix_k + pad_lp * (1 - mix_k) * 1.5
for bus in (pad_mix, BASS, ARP):
    L += bus[0] * duck; R += bus[1] * duck
ir_t = tt(2.6)
ir = [rng.normal(0, 1, len(ir_t)) * np.exp(-ir_t / 0.65) for _ in range(2)]
ir = [lp(x, 6000) / np.sqrt(np.sum(x ** 2)) for x in ir]
rev = [signal.fftconvolve(BUS_REV[i], ir[i])[:N] for i in range(2)]
L += rev[0] * 0.9; R += rev[1] * 0.9
gap = (tN > 40.15) & (tN < 40.5); L[gap] *= 0.12; R[gap] *= 0.12

mix = np.stack([L, R])
mix = signal.sosfilt(signal.butter(2, 28, 'high', fs=SR, output='sos'), mix)
mix = mix / np.max(np.abs(mix)) * 1.4
mix = np.tanh(mix) / np.tanh(1.4)
mix *= np.clip((DUR - tN) / 1.2, 0, 1)
mix = mix / np.max(np.abs(mix)) * 0.89
wavfile.write('out/music.wav', SR, (mix.T * 32767).astype(np.int16))
print('ok')
